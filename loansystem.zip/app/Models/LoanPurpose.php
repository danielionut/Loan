<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class LoanPurpose extends Model
{
    protected $table = "loan_purposes";




}
