<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ClientRelationship extends Model
{
    protected $table = "client_relationships";

    public $timestamps = false;


}
