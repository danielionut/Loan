<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ClientProfession extends Model
{
    protected $table = "client_profession";

    public $timestamps = false;


}
