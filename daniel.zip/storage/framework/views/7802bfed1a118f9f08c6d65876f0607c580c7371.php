<?php $__env->startSection('title'); ?>
    <?php echo e(trans_choice('general.grant',1)); ?> <?php echo e(trans_choice('general.detail',2)); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="panel ">
                <div class="panel-heading">
                    <h6 class="panel-title">#<?php echo e($grant->id); ?></h6>

                    <div class="heading-elements">

                    </div>
                </div>
                <div class="panel-body">
                    <?php if($grant->status=="pending"): ?>
                        <div class="row">
                            <div class="col-md-12">
                                <div class="pull-right btn-group">
                                    <?php if(Sentinel::hasAccess('grants.approve')): ?>
                                        <a href="#" data-toggle="modal" data-target="#approve_grant_modal"
                                           class="btn btn-primary"><i
                                                    class="fa fa-check"></i>&nbsp;<?php echo e(trans_choice('general.approve',1)); ?>

                                        </a>
                                        <a href="#" data-toggle="modal" data-target="#decline_grant_modal"
                                           class="btn btn-primary"><i
                                                    class="fa fa-times"></i>&nbsp;<?php echo e(trans_choice('general.decline',1)); ?>

                                        </a>
                                    <?php endif; ?>
                                    <?php if(Sentinel::hasAccess('grants.update')): ?>
                                        <a href="<?php echo e(url('grant/'.$grant->id.'/edit')); ?>" class="btn btn-primary"><i
                                                    class="fa fa-edit"></i>&nbsp;<?php echo e(trans_choice('general.edit',1)); ?></a>
                                    <?php endif; ?>
                                    <button class="btn btn-primary dropdown-toggle" type="button" data-toggle="dropdown"
                                            aria-expanded="false">More<span class="caret"></span></button>
                                    <ul class="dropdown-menu dropdown-menu-right" role="menu">
                                        <?php if(Sentinel::hasAccess('grants.update')): ?>
                                            <li>
                                                <a href="#"
                                                   data-toggle="modal" data-target="#change_grant_officer_modal">
                                                    <?php echo e(trans_choice('general.change',1)); ?> <?php echo e(trans_choice('general.grant',1)); ?> <?php echo e(trans_choice('general.officer',1)); ?></a>
                                            </li>
                                        <?php endif; ?>
                                        <?php if(Sentinel::hasAccess('grants.approve')): ?>
                                            <li>
                                                <a href="#"
                                                   data-toggle="modal" data-target="#withdraw_grant_modal">
                                                    <?php echo e(trans('general.withdraw')); ?></a>
                                            </li>
                                        <?php endif; ?>
                                        <?php if(Sentinel::hasAccess('grants.delete')): ?>
                                            <li>
                                                <a href="<?php echo e(url('grant/'.$grant->id.'/delete')); ?>"
                                                   class="delete">
                                                    <?php echo e(trans('general.delete')); ?></a>
                                            </li>
                                        <?php endif; ?>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="row m-t-20" style="">
                            <div class="col-sm-7 col-md-7">
                                <table class="table table-striped table-bordered">
                                    <tbody>
                                    <?php if($grant->client_type=="client"): ?>
                                        <tr>
                                            <th class="table-bold-grant"><?php echo e(trans_choice('general.client',1)); ?></th>
                                            <td>
                                        <span class="padded-td">
                                             <?php if(!empty($grant->client)): ?>
                                                <?php if($grant->client->client_type=="individual"): ?>
                                                    <a href="<?php echo e(url('client/'.$grant->client_id.'/show')); ?>"><?php echo e($grant->client->first_name); ?> <?php echo e($grant->client->middle_name); ?> <?php echo e($grant->client->last_name); ?></a>
                                                    (<?php echo e(trans_choice('general.individual',1)); ?>)
                                                <?php else: ?>
                                                    <a href="<?php echo e(url('client/'.$grant->client_id.'/show')); ?>"><?php echo e($grant->client->full_name); ?></a>
                                                    (<?php echo e(trans_choice('general.business',1)); ?>)
                                                <?php endif; ?>
                                            <?php endif; ?>
                                        </span>
                                            </td>
                                        </tr>
                                    <?php endif; ?>
                                    <tr>
                                        <th class="table-bold-grant"><?php echo e(trans_choice('general.currency',1)); ?></th>
                                        <td>
                                        <span class="padded-td">
                                              <?php if(!empty($grant->currency)): ?>
                                                <?php echo e($grant->currency->name); ?>

                                            <?php endif; ?>
                                        </span>
                                        </td>
                                    </tr>
                                    <tr>
                                        <th class="table-bold-grant"><?php echo e(trans_choice('general.grant',1)); ?> <?php echo e(trans_choice('general.officer',1)); ?></th>
                                        <td>
                                        <span class="padded-td">
                                              <?php if(!empty($grant->grant_officer)): ?>
                                                <?php echo e($grant->grant_officer->first_name); ?> <?php echo e($grant->grant_officer->last_name); ?>

                                            <?php endif; ?>
                                        </span>
                                        </td>
                                    </tr>
                                    <tr>
                                        <th class="table-bold-grant"><?php echo e(trans_choice('general.external_id',1)); ?> </th>
                                        <td>
                                            <span class="padded-td"><?php echo e($grant->external_id); ?></span>
                                        </td>
                                    </tr>
                                    </tbody>
                                </table>
                            </div>
                            <div class="col-sm-5 col-md-5">
                                <table class="table table-striped table-bordered">
                                    <tbody>
                                    <tr>
                                        <th class="table-bold-grant"><?php echo e(trans_choice('general.proposed',1)); ?> <?php echo e(trans_choice('general.amount',1)); ?></th>
                                        <td>
                                            <span class="padded-td"><?php echo e(number_format($grant->amount,$grant->decimals)); ?></span>
                                        </td>
                                    </tr>

                                    </tbody>
                                </table>

                            </div>
                        </div>
                        <?php if(Sentinel::hasAccess('grants.approve')): ?>
                            <div class="modal fade" id="approve_grant_modal">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                <span aria-hidden="true">&times;</span></button>
                                            <h4 class="modal-title"><?php echo e(trans_choice('general.approve',1)); ?> <?php echo e(trans_choice('general.grant',1)); ?></h4>
                                        </div>
                                        <form method="post" action="<?php echo e(url('grant/'.$grant->id.'/approve')); ?>"
                                              class="form-horizontal "
                                              enctype="multipart/form-data" id="approve_grant_form">
                                            <?php echo e(csrf_field()); ?>

                                            <div class="modal-body">
                                                <div class="form-group">
                                                    <label for="approved_date"
                                                           class="control-label col-md-3"><?php echo e(trans_choice('general.approved',1)); ?> <?php echo e(trans_choice('general.date',1)); ?></label>
                                                    <div class="col-md-9">
                                                        <input type="text" name="approved_date"
                                                               class="form-control date-picker"
                                                               value="<?php echo e(date("Y-m-d")); ?>"
                                                               required id="approved_date">
                                                    </div>
                                                </div>
                                                <div class="form-group">
                                                    <label for="approved_amount"
                                                           class="control-label col-md-3"><?php echo e(trans_choice('general.amount',1)); ?></label>
                                                    <div class="col-md-9">
                                                        <input type="number" name="approved_amount" class="form-control"
                                                               value="<?php echo e($grant->applied_amount); ?>"
                                                               required id="approved_amount">
                                                    </div>
                                                </div>
                                                <div class="form-group">
                                                    <label for="approved_notes"
                                                           class="control-label col-md-3"><?php echo e(trans_choice('general.note',2)); ?></label>
                                                    <div class="col-md-9">
                                                     <textarea name="approved_notes" class="form-control"
                                                               id="approved_notes"
                                                               rows="3"><?php echo e(old('approved_notes')); ?></textarea>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-default pull-left"
                                                        data-dismiss="modal"><?php echo e(trans_choice('general.close',1)); ?></button>
                                                <button type="submit"
                                                        class="btn btn-primary"><?php echo e(trans_choice('general.save',1)); ?></button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                            <div class="modal fade" id="decline_grant_modal">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                <span aria-hidden="true">&times;</span></button>
                                            <h4 class="modal-title"><?php echo e(trans_choice('general.decline',1)); ?> <?php echo e(trans_choice('general.grant',1)); ?></h4>
                                        </div>
                                        <form method="post" action="<?php echo e(url('grant/'.$grant->id.'/decline')); ?>"
                                              class="form-horizontal "
                                              enctype="multipart/form-data" id="decline_grant_form">
                                            <?php echo e(csrf_field()); ?>

                                            <div class="modal-body">
                                                <div class="form-group">
                                                    <label for="declined_notes"
                                                           class="control-label col-md-3"><?php echo e(trans_choice('general.note',2)); ?></label>
                                                    <div class="col-md-9">
                                                     <textarea name="declined_notes" class="form-control"
                                                               id="declined_notes" rows="3"
                                                               required><?php echo e(old('declined_notes')); ?></textarea>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-default pull-left"
                                                        data-dismiss="modal"><?php echo e(trans_choice('general.close',1)); ?></button>
                                                <button type="submit"
                                                        class="btn btn-primary"><?php echo e(trans_choice('general.save',1)); ?></button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        <?php endif; ?>
                        <div class="modal fade" id="withdraw_grant_modal">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                            <span aria-hidden="true">&times;</span></button>
                                        <h4 class="modal-title"><?php echo e(trans_choice('general.withdraw',1)); ?> <?php echo e(trans_choice('general.grant',1)); ?></h4>
                                    </div>
                                    <form method="post" action="<?php echo e(url('grant/'.$grant->id.'/withdraw')); ?>"
                                          class="form-horizontal "
                                          enctype="multipart/form-data" id="withdraw_grant_form">
                                        <?php echo e(csrf_field()); ?>

                                        <div class="modal-body">
                                            <div class="form-group">
                                                <label for="withdrawn_notes"
                                                       class="control-label col-md-3"><?php echo e(trans_choice('general.note',2)); ?></label>
                                                <div class="col-md-9">
                                                     <textarea name="withdrawn_notes" class="form-control"
                                                               id="declined_notes" rows="3"
                                                               required><?php echo e(old('withdrawn_notes')); ?></textarea>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-default pull-left"
                                                    data-dismiss="modal"><?php echo e(trans_choice('general.close',1)); ?></button>
                                            <button type="submit"
                                                    class="btn btn-primary"><?php echo e(trans_choice('general.save',1)); ?></button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>

                    <?php endif; ?>
                    <?php if($grant->status=="approved"): ?>
                        <div class="row">
                            <div class="col-md-12">
                                <div class="pull-right btn-group">
                                    <?php if(Sentinel::hasAccess('grants.disburse')): ?>
                                        <a href="#" data-toggle="modal" data-target="#disburse_grant_modal"
                                           class="btn btn-primary"><i
                                                    class="fa fa-flag"></i>&nbsp;<?php echo e(trans_choice('general.disburse',1)); ?>

                                        </a>
                                    <?php endif; ?>
                                    <?php if(Sentinel::hasAccess('grants.undo_approval')): ?>
                                        <a href="<?php echo e(url('grant/'.$grant->id.'/unapprove')); ?>"
                                           class="btn btn-primary confirm"><i
                                                    class="fa fa-undo"></i>&nbsp;<?php echo e(trans_choice('general.undo',1)); ?>

                                            &nbsp;<?php echo e(trans_choice('general.approval',1)); ?></a>
                                    <?php endif; ?>
                                    <?php if(Sentinel::hasAccess('grants.update')): ?>
                                        <a href="#"
                                           data-toggle="modal" data-target="#change_grant_officer_modal"
                                           class="btn btn-primary"><i
                                                    class="fa fa-user"></i>&nbsp;
                                            <?php echo e(trans_choice('general.change',1)); ?> <?php echo e(trans_choice('general.grant',1)); ?> <?php echo e(trans_choice('general.officer',1)); ?>

                                        </a>
                                    <?php endif; ?>
                                    <button class="btn btn-primary dropdown-toggle" type="button" data-toggle="dropdown"
                                            aria-expanded="false">More<span class="caret"></span></button>

                                </div>
                            </div>
                        </div>
                        <div class="row m-t-20" style="">
                            <div class="col-sm-7 col-md-7">
                                <table class="table table-striped table-bordered">
                                    <tbody>
                                    <?php if($grant->client_type=="client"): ?>
                                        <tr>
                                            <th class="table-bold-grant"><?php echo e(trans_choice('general.client',1)); ?></th>
                                            <td>
                                        <span class="padded-td">
                                             <?php if(!empty($grant->client)): ?>
                                                <?php if($grant->client->client_type=="individual"): ?>
                                                    <a href="<?php echo e(url('client/'.$grant->client_id.'/show')); ?>"><?php echo e($grant->client->first_name); ?> <?php echo e($grant->client->middle_name); ?> <?php echo e($grant->client->last_name); ?></a>
                                                    (<?php echo e(trans_choice('general.individual',1)); ?>)
                                                <?php else: ?>
                                                    <a href="<?php echo e(url('client/'.$grant->client_id.'/show')); ?>"><?php echo e($grant->client->full_name); ?></a>
                                                    (<?php echo e(trans_choice('general.business',1)); ?>)
                                                <?php endif; ?>
                                            <?php endif; ?>
                                        </span>
                                            </td>
                                        </tr>
                                    <?php endif; ?>
                                    <?php if($grant->client_type=="group"): ?>
                                        <tr>
                                            <th class="table-bold-grant"><?php echo e(trans_choice('general.group',1)); ?></th>
                                            <td>
                                        <span class="padded-td">
                                             <?php if(!empty($grant->group)): ?>
                                                <a href="<?php echo e(url('group/'.$grant->group_id.'/show')); ?>"><?php echo e($grant->group->name); ?></a>
                                            <?php endif; ?>
                                        </span>
                                            </td>
                                        </tr>
                                    <?php endif; ?>
                                    <tr>
                                        <th class="table-bold-grant"><?php echo e(trans_choice('general.currency',1)); ?></th>
                                        <td>
                                        <span class="padded-td">
                                              <?php if(!empty($grant->currency)): ?>
                                                <?php echo e($grant->currency->name); ?>

                                            <?php endif; ?>
                                        </span>
                                        </td>
                                    </tr>
                                    <tr>
                                        <th class="table-bold-grant"><?php echo e(trans_choice('general.grant',1)); ?> <?php echo e(trans_choice('general.officer',1)); ?></th>
                                        <td>
                                        <span class="padded-td">
                                              <?php if(!empty($grant->grant_officer)): ?>
                                                <?php echo e($grant->grant_officer->first_name); ?> <?php echo e($grant->grant_officer->last_name); ?>

                                            <?php endif; ?>
                                        </span>
                                        </td>
                                    </tr>
                                    <tr>
                                        <th class="table-bold-grant"><?php echo e(trans_choice('general.external_id',1)); ?> </th>
                                        <td>
                                            <span class="padded-td"><?php echo e($grant->external_id); ?></span>
                                        </td>
                                    </tr>
                                    </tbody>
                                </table>
                            </div>
                            <div class="col-sm-5 col-md-5">
                                <table class="table table-striped table-bordered">
                                    <tbody>

                                    <tr>
                                        <th class="table-bold-grant"><?php echo e(trans_choice('general.proposed',1)); ?> <?php echo e(trans_choice('general.amount',1)); ?></th>
                                        <td>
                                            <span class="padded-td"><?php echo e(number_format($grant->applied_amount,$grant->decimals)); ?></span>
                                        </td>
                                    </tr>
                                    <tr>
                                        <th class="table-bold-grant"><?php echo e(trans_choice('general.approved',1)); ?> <?php echo e(trans_choice('general.amount',1)); ?></th>
                                        <td>
                                            <span class="padded-td"><?php echo e(number_format($grant->approved_amount,$grant->decimals)); ?></span>
                                        </td>
                                    </tr>
                                    <tr class="hidden">
                                        <th class="table-bold-grant"><?php echo e(trans_choice('general.expected',1)); ?> <?php echo e(trans_choice('general.disbursement',1)); ?> <?php echo e(trans_choice('general.date',1)); ?></th>
                                        <td>
                                            <span class="padded-td"><?php echo e($grant->expected_disbursement_date); ?></span>
                                        </td>
                                    </tr>
                                    </tbody>
                                </table>

                            </div>
                        </div>
                        <div class="modal fade" id="disburse_grant_modal">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                            <span aria-hidden="true">&times;</span></button>
                                        <h4 class="modal-title"><?php echo e(trans_choice('general.disburse',1)); ?> <?php echo e(trans_choice('general.grant',1)); ?></h4>
                                    </div>
                                    <form method="post" action="<?php echo e(url('grant/'.$grant->id.'/disburse')); ?>"
                                          class="form-horizontal "
                                          enctype="multipart/form-data" id="disburse_grant_form">
                                        <?php echo e(csrf_field()); ?>

                                        <div class="modal-body">
                                            <div class="form-group">
                                                <label for="disbursement_date"
                                                       class="control-label col-md-4"><?php echo e(trans_choice('general.disbursement',1)); ?> <?php echo e(trans_choice('general.date',1)); ?></label>
                                                <div class="col-md-8">
                                                    <input type="text" name="disbursement_date"
                                                           class="form-control date-picker"
                                                           value="<?php echo e($grant->expected_disbursement_date); ?>"
                                                           required id="disbursement_date">
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <label for="payment_type_id"
                                                       class="control-label col-md-4"><?php echo e(trans_choice('general.payment',1)); ?> <?php echo e(trans_choice('general.type',1)); ?>

                                                </label>
                                                <div class="col-md-8">
                                                    <select name="payment_type_id" class="form-control select2"
                                                            id="payment_type_id" required>
                                                        <option></option>
                                                        <?php $__currentLoopData = \App\Models\PaymentType::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($key->id); ?>"><?php echo e($key->name); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <label for="approved_amount"
                                                       class="control-label col-md-4"><?php echo e(trans_choice('general.show',1)); ?> <?php echo e(trans_choice('general.payment',1)); ?> <?php echo e(trans_choice('general.detail',2)); ?></label>
                                                <div class="col-md-8">
                                                    <button type="button" class="btn btn-primary" data-toggle="collapse"
                                                            data-target="#show_payment_details">
                                                        <i class="fa fa-plus"></i>
                                                    </button>
                                                </div>
                                            </div>
                                            <div id="show_payment_details" class="collapse">
                                                <div class="form-group">
                                                    <label for="account_number"
                                                           class="control-label col-md-4"><?php echo e(trans_choice('general.account',1)); ?>

                                                        #</label>
                                                    <div class="col-md-8">
                                                        <input type="text" name="account_number"
                                                               class="form-control"
                                                               value=""
                                                               id="account_number">
                                                    </div>
                                                </div>
                                                <div class="form-group">
                                                    <label for="cheque_number"
                                                           class="control-label col-md-4"><?php echo e(trans_choice('general.cheque',1)); ?>

                                                        #</label>
                                                    <div class="col-md-8">
                                                        <input type="text" name="cheque_number"
                                                               class="form-control"
                                                               value=""
                                                               id="cheque_number">
                                                    </div>
                                                </div>
                                                <div class="form-group">
                                                    <label for="routing_code"
                                                           class="control-label col-md-4"><?php echo e(trans_choice('general.routing_code',1)); ?></label>
                                                    <div class="col-md-8">
                                                        <input type="text" name="routing_code"
                                                               class="form-control"
                                                               value=""
                                                               id="routing_code">
                                                    </div>
                                                </div>
                                                <div class="form-group">
                                                    <label for="receipt_number"
                                                           class="control-label col-md-4"><?php echo e(trans_choice('general.receipt',1)); ?>

                                                        #</label>
                                                    <div class="col-md-8">
                                                        <input type="text" name="receipt_number"
                                                               class="form-control"
                                                               value=""
                                                               id="receipt_number">
                                                    </div>
                                                </div>
                                                <div class="form-group">
                                                    <label for="bank"
                                                           class="control-label col-md-4"><?php echo e(trans_choice('general.bank',1)); ?>

                                                        #</label>
                                                    <div class="col-md-8">
                                                        <input type="text" name="bank"
                                                               class="form-control"
                                                               value=""
                                                               id="bank">
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <label for="disbursed_notes"
                                                       class="control-label col-md-4"><?php echo e(trans_choice('general.note',2)); ?></label>
                                                <div class="col-md-8">
                                                     <textarea name="disbursed_notes" class="form-control"
                                                               id="disbursed_notes"
                                                               rows="3"><?php echo e(old('disbursed_notes')); ?></textarea>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-default pull-left"
                                                    data-dismiss="modal"><?php echo e(trans_choice('general.close',1)); ?></button>
                                            <button type="submit"
                                                    class="btn btn-primary"><?php echo e(trans_choice('general.save',1)); ?></button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>

                    <?php endif; ?>
                    <?php if($grant->status=="disbursed"): ?>
                        <div class="row">
                            <div class="col-md-12">
                                <div class="pull-right btn-group">
                                    <?php if(Sentinel::hasAccess('grants.update')): ?>
                                        <a href="#"
                                           data-toggle="modal" data-target="#change_grant_officer_modal"
                                           class="btn btn-primary"><i
                                                    class="fa fa-user"></i>&nbsp;
                                            <?php echo e(trans_choice('general.change',1)); ?> <?php echo e(trans_choice('general.grant',1)); ?> <?php echo e(trans_choice('general.officer',1)); ?>

                                        </a>
                                    <?php endif; ?>
                                    <?php if(Sentinel::hasAccess('grants.undo_disbursement')): ?>
                                        <a href="<?php echo e(url('grant/'.$grant->id.'/undisburse')); ?>"
                                           class="btn btn-primary confirm"><i
                                                    class="fa fa-undo"></i>&nbsp;<?php echo e(trans_choice('general.undo',1)); ?>

                                            &nbsp;<?php echo e(trans_choice('general.disbursement',1)); ?></a>
                                    <?php endif; ?>
                                    <button class="btn btn-primary dropdown-toggle" type="button" data-toggle="dropdown"
                                            aria-expanded="false">More <span class="caret"></span></button>
                                    <ul class="dropdown-menu dropdown-menu-right" role="menu">

                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="row m-t-20" style="">
                            <div class="col-sm-8 col-md-8">
                                <table class="table table-striped table-bordered">
                                    <tbody>
                                    <?php if($grant->client_type=="client"): ?>
                                        <tr>
                                            <th class="table-bold-grant"><?php echo e(trans_choice('general.client',1)); ?></th>
                                            <td>
                                        <span class="padded-td">
                                             <?php if(!empty($grant->client)): ?>
                                                <?php if($grant->client->client_type=="individual"): ?>
                                                    <a href="<?php echo e(url('client/'.$grant->client_id.'/show')); ?>"><?php echo e($grant->client->first_name); ?> <?php echo e($grant->client->middle_name); ?> <?php echo e($grant->client->last_name); ?></a>
                                                    (<?php echo e(trans_choice('general.individual',1)); ?>)
                                                <?php else: ?>
                                                    <a href="<?php echo e(url('client/'.$grant->client_id.'/show')); ?>"><?php echo e($grant->client->full_name); ?></a>
                                                    (<?php echo e(trans_choice('general.business',1)); ?>)
                                                <?php endif; ?>
                                            <?php endif; ?>
                                        </span>
                                            </td>
                                        </tr>
                                    <?php endif; ?>
                                    <?php if($grant->client_type=="group"): ?>
                                        <tr>
                                            <th class="table-bold-grant"><?php echo e(trans_choice('general.group',1)); ?></th>
                                            <td>
                                        <span class="padded-td">
                                             <?php if(!empty($grant->group)): ?>
                                                <a href="<?php echo e(url('group/'.$grant->group_id.'/show')); ?>"><?php echo e($grant->group->name); ?></a>
                                            <?php endif; ?>
                                        </span>
                                            </td>
                                        </tr>
                                    <?php endif; ?>
                                    <tr>
                                        <th class="table-bold-grant"><?php echo e(trans_choice('general.currency',1)); ?></th>
                                        <td>
                                        <span class="padded-td">
                                              <?php if(!empty($grant->currency)): ?>
                                                <?php echo e($grant->currency->name); ?>

                                            <?php endif; ?>
                                        </span>
                                        </td>
                                    </tr>
                                    <tr>
                                        <th class="table-bold-grant"><?php echo e(trans_choice('general.grant',1)); ?> <?php echo e(trans_choice('general.officer',1)); ?></th>
                                        <td>
                                        <span class="padded-td">
                                              <?php if(!empty($grant->grant_officer)): ?>
                                                <?php echo e($grant->grant_officer->first_name); ?> <?php echo e($grant->grant_officer->last_name); ?>

                                            <?php endif; ?>
                                        </span>
                                        </td>
                                    </tr>
                                    <tr>
                                        <th class="table-bold-grant"><?php echo e(trans_choice('general.external_id',1)); ?> </th>
                                        <td>
                                            <span class="padded-td"><?php echo e($grant->external_id); ?></span>
                                        </td>
                                    </tr>
                                    </tbody>
                                </table>
                            </div>
                            <div class="col-sm-4 col-md-4">
                                <table class="table table-striped table-bordered">
                                    <tbody>

                                    <tr>
                                        <th class="table-bold-grant"><?php echo e(trans_choice('general.proposed',1)); ?> <?php echo e(trans_choice('general.amount',1)); ?></th>
                                        <td>
                                            <span class="padded-td"><?php echo e(number_format($grant->applied_amount,$grant->decimals)); ?></span>
                                        </td>
                                    </tr>
                                    <tr>
                                        <th class="table-bold-grant"><?php echo e(trans_choice('general.approved',1)); ?> <?php echo e(trans_choice('general.amount',1)); ?></th>
                                        <td>
                                            <span class="padded-td"><?php echo e(number_format($grant->approved_amount,$grant->decimals)); ?></span>
                                        </td>
                                    </tr>
                                    <tr>
                                        <th class="table-bold-grant"> <?php echo e(trans_choice('general.disbursed',1)); ?> <?php echo e(trans_choice('general.amount',1)); ?></th>
                                        <td>
                                            <span class="padded-td"><?php echo e(number_format($grant->amount,$grant->decimals)); ?></span>
                                        </td>
                                    </tr>
                                    <tr>
                                        <th class="table-bold-grant"><?php echo e(trans_choice('general.disbursement',1)); ?> <?php echo e(trans_choice('general.date',1)); ?></th>
                                        <td>
                                            <span class="padded-td"><?php echo e($grant->disbursement_date); ?></span>
                                        </td>
                                    </tr>
                                    </tbody>
                                </table>

                            </div>
                        </div>
                        <div class="modal fade" id="disburse_grant_modal">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                            <span aria-hidden="true">&times;</span></button>
                                        <h4 class="modal-title"><?php echo e(trans_choice('general.disburse',1)); ?> <?php echo e(trans_choice('general.grant',1)); ?></h4>
                                    </div>
                                    <form method="post" action="<?php echo e(url('grant/'.$grant->id.'/disburse')); ?>"
                                          class="form-horizontal "
                                          enctype="multipart/form-data" id="disburse_grant_form">
                                        <?php echo e(csrf_field()); ?>

                                        <div class="modal-body">
                                            <div class="form-group">
                                                <label for="disbursement_date"
                                                       class="control-label col-md-4"><?php echo e(trans_choice('general.disbursement',1)); ?> <?php echo e(trans_choice('general.date',1)); ?></label>
                                                <div class="col-md-8">
                                                    <input type="text" name="disbursement_date"
                                                           class="form-control date-picker"
                                                           value="<?php echo e($grant->expected_disbursement_date); ?>"
                                                           required id="disbursement_date">
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <label for="first_repayment_date"
                                                       class="control-label col-md-4"><?php echo e(trans_choice('general.first',1)); ?> <?php echo e(trans_choice('general.repayment',1)); ?> <?php echo e(trans_choice('general.date',1)); ?></label>
                                                <div class="col-md-8">
                                                    <input type="text" name="first_repayment_date"
                                                           class="form-control date-picker"
                                                           value="<?php echo e($grant->expected_first_repayment_date); ?>"
                                                           required id="first_repayment_date">
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <label for="payment_type_id"
                                                       class="control-label col-md-4"><?php echo e(trans_choice('general.payment',1)); ?> <?php echo e(trans_choice('general.type',1)); ?>

                                                </label>
                                                <div class="col-md-8">
                                                    <select name="payment_type_id" class="form-control select2"
                                                            id="payment_type_id" required>
                                                        <option></option>
                                                        <?php $__currentLoopData = \App\Models\PaymentType::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($key->id); ?>"><?php echo e($key->name); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <label for="approved_amount"
                                                       class="control-label col-md-4"><?php echo e(trans_choice('general.show',1)); ?> <?php echo e(trans_choice('general.payment',1)); ?> <?php echo e(trans_choice('general.detail',2)); ?></label>
                                                <div class="col-md-8">
                                                    <button type="button" class="btn btn-primary" data-toggle="collapse"
                                                            data-target="#show_payment_details">
                                                        <i class="fa fa-plus"></i>
                                                    </button>
                                                </div>
                                            </div>
                                            <div id="show_payment_details" class="collapse">
                                                <div class="form-group">
                                                    <label for="account_number"
                                                           class="control-label col-md-4"><?php echo e(trans_choice('general.account',1)); ?>

                                                        #</label>
                                                    <div class="col-md-8">
                                                        <input type="text" name="account_number"
                                                               class="form-control"
                                                               value=""
                                                               id="account_number">
                                                    </div>
                                                </div>
                                                <div class="form-group">
                                                    <label for="cheque_number"
                                                           class="control-label col-md-4"><?php echo e(trans_choice('general.cheque',1)); ?>

                                                        #</label>
                                                    <div class="col-md-8">
                                                        <input type="text" name="cheque_number"
                                                               class="form-control"
                                                               value=""
                                                               id="cheque_number">
                                                    </div>
                                                </div>
                                                <div class="form-group">
                                                    <label for="routing_code"
                                                           class="control-label col-md-4"><?php echo e(trans_choice('general.routing_code',1)); ?></label>
                                                    <div class="col-md-8">
                                                        <input type="text" name="routing_code"
                                                               class="form-control"
                                                               value=""
                                                               id="routing_code">
                                                    </div>
                                                </div>
                                                <div class="form-group">
                                                    <label for="receipt_number"
                                                           class="control-label col-md-4"><?php echo e(trans_choice('general.receipt',1)); ?>

                                                        #</label>
                                                    <div class="col-md-8">
                                                        <input type="text" name="receipt_number"
                                                               class="form-control"
                                                               value=""
                                                               id="receipt_number">
                                                    </div>
                                                </div>
                                                <div class="form-group">
                                                    <label for="bank"
                                                           class="control-label col-md-4"><?php echo e(trans_choice('general.bank',1)); ?>

                                                        #</label>
                                                    <div class="col-md-8">
                                                        <input type="text" name="bank"
                                                               class="form-control"
                                                               value=""
                                                               id="bank">
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <label for="disbursed_notes"
                                                       class="control-label col-md-4"><?php echo e(trans_choice('general.note',2)); ?></label>
                                                <div class="col-md-8">
                                                     <textarea name="disbursed_notes" class="form-control"
                                                               id="disbursed_notes"
                                                               rows="3"><?php echo e(old('disbursed_notes')); ?></textarea>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-default pull-left"
                                                    data-dismiss="modal"><?php echo e(trans_choice('general.close',1)); ?></button>
                                            <button type="submit"
                                                    class="btn btn-primary"><?php echo e(trans_choice('general.save',1)); ?></button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>

                    <?php endif; ?>
                    <?php if($grant->status=="withdrawn"): ?>
                        <div class="row">
                            <div class="col-md-12">
                                <blockquote>
                                    <p><?php echo e($grant->withdrawn_notes); ?></p>
                                    <small><?php echo e($grant->withdrawn_date); ?></small>
                                </blockquote>
                            </div>
                        </div>
                    <?php endif; ?>
                    <?php if($grant->status=="declined"): ?>
                        <div class="row">
                            <div class="col-md-12">
                                <blockquote>
                                    <p><?php echo e($grant->declined_notes); ?></p>
                                    <small><?php echo e($grant->declined_date); ?></small>
                                </blockquote>
                            </div>
                        </div>
                    <?php endif; ?>
                    <?php if($grant->status=="written_off"): ?>
                        <div class="row">
                            <div class="col-md-12">
                                <blockquote>
                                    <p><?php echo e($grant->written_off_notes); ?></p>
                                    <small><?php echo e($grant->written_off_date); ?></small>
                                </blockquote>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-12">
            <div class="nav-tabs-custom">
                <ul class="nav nav-tabs">
                    <?php if(Sentinel::hasAccess('grants.view')): ?>
                        <li class="active"><a href="#account_details" data-toggle="tab"
                                              aria-expanded="false"><?php echo e(trans_choice('general.account',1)); ?> <?php echo e(trans_choice('general.detail',2)); ?></a>
                        </li>
                    <?php endif; ?>
                    <?php if(Sentinel::hasAccess('grants.documents.view')): ?>
                        <li class=""><a href="#documents" data-toggle="tab"
                                        aria-expanded="false"><?php echo e(trans_choice('general.document',2)); ?></a>
                        </li>
                    <?php endif; ?>
                    <?php if(Sentinel::hasAccess('grants.notes.view')): ?>
                        <li class=""><a href="#notes" data-toggle="tab"
                                        aria-expanded="false"><?php echo e(trans_choice('general.note',2)); ?></a>
                        </li>
                    <?php endif; ?>
                    <?php if($grant->client_type=="group"): ?>
                        <li class=""><a href="#group_allocation" data-toggle="tab"
                                        aria-expanded="false"><?php echo e(trans_choice('general.group',1)); ?> <?php echo e(trans_choice('general.allocation',1)); ?></a>
                        </li>
                    <?php endif; ?>
                </ul>
                <div class="tab-content">
                    <div class="tab-pane active" id="account_details">
                        <table class="table table-striped table-hover">
                            <tr>
                                <td><?php echo e(trans_choice('general.amount',1)); ?></td>
                                <td>
                                    <?php echo e(number_format($grant->amount,$grant->decimals)); ?>

                                </td>
                            </tr>
                            <?php if($grant->status=="disbursed"): ?>
                                <?php if(!empty($grant->payment_detail)): ?>
                                    <?php if(!empty($grant->payment_detail->type)): ?>
                                        <tr>
                                            <td><?php echo e(trans_choice('general.payment',1)); ?> <?php echo e(trans_choice('general.type',1)); ?></td>
                                            <td>
                                                <?php echo e($grant->payment_detail->type->name); ?>

                                            </td>
                                        </tr>
                                    <?php endif; ?>
                                    <?php if(!empty($grant->payment_detail->account_number)): ?>
                                        <tr>
                                            <td><?php echo e(trans_choice('general.account',1)); ?>#</td>
                                            <td>
                                                <?php echo e($grant->payment_detail->account_number); ?>

                                            </td>
                                        </tr>
                                    <?php endif; ?>
                                    <?php if(!empty($grant->payment_detail->cheque_number)): ?>
                                        <tr>
                                            <td><?php echo e(trans_choice('general.cheque',1)); ?>#</td>
                                            <td>
                                                <?php echo e($grant->payment_detail->cheque_number); ?>

                                            </td>
                                        </tr>
                                    <?php endif; ?>
                                    <?php if(!empty($grant->payment_detail->routing_code)): ?>
                                        <tr>
                                            <td><?php echo e(trans_choice('general.routing_code',1)); ?>#</td>
                                            <td>
                                                <?php echo e($grant->payment_detail->routing_code); ?>

                                            </td>
                                        </tr>
                                    <?php endif; ?>
                                    <?php if(!empty($grant->payment_detail->receipt_number)): ?>
                                        <tr>
                                            <td><?php echo e(trans_choice('general.receipt',1)); ?>#</td>
                                            <td>
                                                <?php echo e($grant->payment_detail->receipt_number); ?>

                                            </td>
                                        </tr>
                                    <?php endif; ?>
                                    <?php if(!empty($grant->payment_detail->bank)): ?>
                                        <tr>
                                            <td><?php echo e(trans_choice('general.bank',1)); ?>#</td>
                                            <td>
                                                <?php echo e($grant->payment_detail->bank); ?>

                                            </td>
                                        </tr>
                                    <?php endif; ?>
                                <?php endif; ?>
                            <?php endif; ?>
                            <tr>
                                <td><?php echo e(trans_choice('general.note',2)); ?></td>
                                <td>
                                    <?php echo e($grant->notes); ?>

                                </td>
                            </tr>

                            <?php $__currentLoopData = \App\Models\CustomFieldMeta::where('category', 'grants')->where('parent_id', $grant->id)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td>
                                        <?php if(!empty($key->custom_field)): ?>
                                            <?php echo e($key->custom_field->name); ?>

                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if($key->custom_field->field_type=="checkbox"): ?>
                                            <?php $__currentLoopData = unserialize($key->name); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v=>$k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php echo e($k); ?><br>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php else: ?>
                                            <?php echo e($key->name); ?>

                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e(trans_choice('general.submitted',1)); ?> <?php echo e(trans_choice('general.on',1)); ?></td>
                                <td>
                                    <?php echo e($grant->created_date); ?>

                                    <?php if(!empty($grant->created_by)): ?>
                                        by <?php echo e($grant->created_by->first_name); ?> <?php echo e($grant->created_by->last_name); ?>

                                    <?php endif; ?>
                                </td>
                            </tr>
                            <tr>
                                <td><?php echo e(trans_choice('general.approved',1)); ?> <?php echo e(trans_choice('general.on',1)); ?></td>
                                <td>
                                    <?php echo e($grant->approved_date); ?>

                                    <?php if(!empty($grant->approved_by)): ?>
                                        by <?php echo e($grant->approved_by->first_name); ?> <?php echo e($grant->approved_by->last_name); ?>

                                    <?php endif; ?>
                                </td>
                            </tr>
                            <tr>
                                <td><?php echo e(trans_choice('general.disbursed',1)); ?> <?php echo e(trans_choice('general.on',1)); ?></td>
                                <td>
                                    <?php echo e($grant->disbursed_date); ?>

                                    <?php if(!empty($grant->disbursed_by)): ?>
                                        by <?php echo e($grant->disbursed_by->first_name); ?> <?php echo e($grant->disbursed_by->last_name); ?>

                                    <?php endif; ?>
                                </td>
                            </tr>
                        </table>
                    </div>
                    <?php if(Sentinel::hasAccess('grants.documents.view')): ?>
                        <div class="tab-pane" id="documents">
                            <div class="row">
                                <div class="col-md-12">
                                    <?php if(Sentinel::hasAccess('grants.documents.create')): ?>
                                        <a href="#add_document_modal"
                                           data-toggle="modal" class="btn btn-info pull-right"><i
                                                    class="fa fa-plus"></i> <?php echo e(trans_choice('general.add',1)); ?> <?php echo e(trans_choice('general.document',1)); ?>

                                        </a>
                                    <?php endif; ?>
                                </div>
                                <div class="col-md-12 table-responsive">
                                    <table class="table table-hover table-striped" id="">
                                        <thead>
                                        <tr>
                                            <th><?php echo e(trans_choice('general.name',1)); ?></th>
                                            <th><?php echo e(trans('general.description')); ?></th>
                                            <th><?php echo e(trans_choice('general.action',1)); ?></th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        <?php $__currentLoopData = \App\Models\Document::where('record_id',$grant->id)->where('type','grant')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($key->name); ?></td>
                                                <td><?php echo $key->notes; ?></td>
                                                <td>
                                                    <a class="" href="<?php echo e(asset('uploads/'.$key->location)); ?>"
                                                       target="_blank"><i class="fa fa-download"></i> </a>
                                                    <?php if(Sentinel::hasAccess('grants.documents.delete')): ?>
                                                        <a class="confirm"
                                                           href="<?php echo e(url('grant/document/'.$key->id.'/delete')); ?>"><i
                                                                    class="fa fa-trash"></i> </a>
                                                    <?php endif; ?>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    <?php endif; ?>

                    <?php if(Sentinel::hasAccess('grants.guarantors.view')): ?>
                        <div class="tab-pane" id="guarantors">
                            <div class="row">
                                <div class="col-md-12">
                                    <?php if(Sentinel::hasAccess('grants.guarantors.create')): ?>
                                        <a href="#add_guarantor_modal"
                                           data-toggle="modal" class="btn btn-info pull-right"><i
                                                    class="fa fa-plus"></i> <?php echo e(trans_choice('general.add',1)); ?> <?php echo e(trans_choice('general.guarantor',1)); ?>

                                        </a>
                                    <?php endif; ?>
                                </div>
                                <div class="col-md-12 table-responsive">
                                    <table id="" class="table table-striped table-condensed table-hover">
                                        <thead>
                                        <tr>
                                            <th><?php echo e(trans_choice('general.name',1)); ?></th>
                                            <th><?php echo e(trans_choice('general.relationship',1)); ?></th>
                                            <th><?php echo e(trans_choice('general.type',1)); ?></th>
                                            <th><?php echo e(trans_choice('general.amount',1)); ?></th>
                                            <th><?php echo e(trans_choice('general.mobile',1)); ?></th>
                                            <th><?php echo e(trans_choice('general.action',1)); ?></th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        <?php $__currentLoopData = $grant->guarantors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td>
                                                    <?php if($key->is_client==1): ?>
                                                        <?php if(!empty($key->client)): ?>
                                                            <a href="<?php echo e(url('client/'.$key->client_id.'/show')); ?>"><?php echo e($key->client->first_name); ?> <?php echo e($key->client->midddle_name); ?> <?php echo e($key->client->last_name); ?></a>
                                                        <?php endif; ?>
                                                    <?php else: ?>
                                                        <?php echo e($key->first_name); ?> <?php echo e($key->midddle_name); ?> <?php echo e($key->last_name); ?>

                                                    <?php endif; ?>
                                                </td>
                                                <td>
                                                    <?php if(!empty($key->relationship)): ?>
                                                        <?php echo e($key->relationship->name); ?>

                                                    <?php endif; ?>
                                                </td>
                                                <td>
                                                    <?php if($key->is_client==1): ?>
                                                        <?php echo e(trans_choice('general.client',1)); ?>

                                                    <?php else: ?>
                                                        <?php echo e(trans_choice('general.external',1)); ?>

                                                    <?php endif; ?>
                                                </td>
                                                <td><?php echo e($key->amount); ?></td>
                                                <td>
                                                    <?php if($key->is_client==1): ?>
                                                        <?php if(!empty($key->client)): ?>
                                                            <?php echo e($key->client->mobile); ?>

                                                        <?php endif; ?>
                                                    <?php else: ?>
                                                        <?php echo e($key->mobile); ?>

                                                    <?php endif; ?>


                                                </td>
                                                <td>
                                                    <?php if($key->is_client==1): ?>
                                                        <a href="<?php echo e(url('client/'.$key->client_id.'/show')); ?>"><i
                                                                    class="fa fa-eye"></i> </a>
                                                    <?php else: ?>
                                                        <a data-id="<?php echo e($key->id); ?>" href="#" data-toggle="modal"
                                                           data-target="#view_guarantor"><i class="fa fa-eye"></i> </a>
                                                    <?php endif; ?>
                                                    <?php if(Sentinel::hasAccess('grants.guarantors.update')): ?>
                                                        <a data-id="<?php echo e($key->id); ?>" href="#" data-toggle="modal"
                                                           data-target="#edit_guarantor"><i class="fa fa-edit"></i> </a>
                                                    <?php endif; ?>
                                                    <?php if(Sentinel::hasAccess('grants.guarantors.delete')): ?>
                                                        <a class="confirm"
                                                           href="<?php echo e(url('grant/guarantor/'.$key->id.'/delete')); ?>"><i
                                                                    class="fa fa-trash"></i> </a>
                                                    <?php endif; ?>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    <?php endif; ?>
                    <?php if(Sentinel::hasAccess('grants.notes.view')): ?>
                        <div class="tab-pane" id="notes">
                            <div class="row">
                                <div class="col-md-12">
                                    <?php if(Sentinel::hasAccess('grants.notes.create')): ?>
                                        <a href="#add_note_modal"
                                           data-toggle="modal" class="btn btn-info pull-right"><i
                                                    class="fa fa-plus"></i> <?php echo e(trans_choice('general.add',1)); ?> <?php echo e(trans_choice('general.note',1)); ?>

                                        </a>
                                    <?php endif; ?>
                                </div>
                                <div class="col-md-12 table-responsive">
                                    <table class="table table-hover table-striped" id="">
                                        <thead>
                                        <tr>
                                            <th><?php echo e(trans_choice('general.note',1)); ?></th>
                                            <th><?php echo e(trans('general.date')); ?></th>
                                            <th><?php echo e(trans('general.created_by')); ?></th>
                                            <th><?php echo e(trans_choice('general.action',1)); ?></th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        <?php $__currentLoopData = \App\Models\Note::where('reference_id',$grant->id)->where('type','grant')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo $key->notes; ?></td>
                                                <td><?php echo $key->created_at; ?></td>
                                                <td>
                                                    <?php if(!empty($key->created_by)): ?>
                                                        <?php echo e($key->created_by->first_name); ?> <?php echo e($key->created_by->last_name); ?>

                                                    <?php endif; ?>
                                                </td>
                                                <td>
                                                    <a data-id="<?php echo e($key->id); ?>" href="#" data-toggle="modal"
                                                       data-target="#view_note"><i class="fa fa-eye"></i> </a>
                                                    <?php if(Sentinel::hasAccess('grants.notes.update')): ?>
                                                        <a data-id="<?php echo e($key->id); ?>" href="#" data-toggle="modal"
                                                           data-target="#edit_note"><i class="fa fa-edit"></i> </a>
                                                    <?php endif; ?>
                                                    <?php if(Sentinel::hasAccess('grants.notes.delete')): ?>
                                                        <a class="confirm"
                                                           href="<?php echo e(url('grant/note/'.$key->id.'/delete')); ?>"><i
                                                                    class="fa fa-trash"></i> </a>
                                                    <?php endif; ?>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    <?php endif; ?>
                    <?php if($grant->client_type=="group"): ?>
                        <div class="tab-pane" id="group_allocation">
                            <div class="row">
                                <div class="col-md-12 table-responsive">
                                    <table class="table table-hover table-striped" id="">
                                        <thead>
                                        <tr>
                                            <th><?php echo e(trans_choice('general.name',1)); ?></th>
                                            <th><?php echo e(trans('general.id')); ?></th>
                                            <th><?php echo e(trans('general.amount')); ?></th>
                                            <th><?php echo e(trans_choice('general.action',1)); ?></th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        <?php $__currentLoopData = $grant->group_allocation; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <?php if(!empty($key->client)): ?>
                                                    <td>
                                                        <?php if($key->client->client_type=="individual"): ?>
                                                            <?php echo e($key->client->first_name); ?> <?php echo e($key->client->middle_name); ?> <?php echo e($key->client->last_name); ?>

                                                        <?php else: ?>
                                                            <?php echo e($key->client->full_name); ?>

                                                        <?php endif; ?>
                                                    </td>
                                                    <td><?php echo e($key->client->account_no); ?></td>
                                                    <td>
                                                        <?php echo e(number_format($key->amount,2)); ?>

                                                    </td>
                                                    <td>
                                                        <a class="" href="<?php echo e(url('client/'.$key->client_id.'/show')); ?>"><i
                                                                    class="fa fa-eye"></i> </a>
                                                    </td>
                                                <?php endif; ?>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
    <div class="modal fade" id="change_grant_officer_modal">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span></button>
                    <h4 class="modal-title"><?php echo e(trans_choice('general.change',1)); ?> <?php echo e(trans_choice('general.grant',1)); ?> <?php echo e(trans_choice('general.officer',1)); ?></h4>
                </div>
                <form method="post" action="<?php echo e(url('grant/'.$grant->id.'/change_grant_officer')); ?>"
                      class="form-horizontal "
                      enctype="multipart/form-data" id="change_grant_officer_form">
                    <?php echo e(csrf_field()); ?>

                    <div class="modal-body">
                        <div class="form-group">
                            <label for="grant_officer_id"
                                   class="control-label col-md-3">
                                <?php echo e(trans_choice('general.grant',1)); ?> <?php echo e(trans_choice('general.officer',1)); ?>

                            </label>
                            <div class="col-md-9">
                                <select name="grant_officer_id" class="form-control select2"
                                        id="grant_officer_id" required>
                                    <option></option>
                                    <?php $__currentLoopData = \App\Models\User::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if(!Sentinel::findUserById($key->id)->inRole('client')): ?>
                                            <option value="<?php echo e($key->id); ?>"
                                                    <?php if($grant->grant_officer_id==$key->id): ?> selected <?php endif; ?>><?php echo e($key->first_name); ?> <?php echo e($key->last_name); ?></option>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-default pull-left"
                                data-dismiss="modal"><?php echo e(trans_choice('general.close',1)); ?></button>
                        <button type="submit"
                                class="btn btn-primary"><?php echo e(trans_choice('general.save',1)); ?></button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <div class="modal fade" id="add_document_modal">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span></button>
                    <h4 class="modal-title"><?php echo e(trans_choice('general.add',1)); ?> <?php echo e(trans_choice('general.document',1)); ?></h4>
                </div>
                <form method="post" action="<?php echo e(url('grant/'.$grant->id.'/document/store')); ?>"
                      class="form-horizontal "
                      enctype="multipart/form-data" id="add_document_form">
                    <?php echo e(csrf_field()); ?>

                    <div class="modal-body">

                        <div class="form-group">
                            <label for="document_name"
                                   class="control-label col-md-3"><?php echo e(trans_choice('general.name',1)); ?></label>
                            <div class="col-md-9">
                                <input type="text" name="name" class="form-control"
                                       value="<?php echo e(old('name')); ?>"
                                       required id="document_name">
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="document_notes"
                                   class="control-label col-md-3"><?php echo e(trans_choice('general.description',2)); ?></label>
                            <div class="col-md-9">
       <textarea name="notes" class="form-control"
                 id="document_notes" rows="3"><?php echo e(old('notes')); ?></textarea>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="document_attachment"
                                   class="control-label col-md-3"><?php echo e(trans_choice('general.attachment',1)); ?></label>
                            <div class="col-md-9">
                                <input type="file" name="attachment" class="form-control" required
                                       id="document_attachment">
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-default pull-left"
                                data-dismiss="modal"><?php echo e(trans_choice('general.close',1)); ?></button>
                        <button type="submit" class="btn btn-primary"><?php echo e(trans_choice('general.save',1)); ?></button>
                    </div>
                </form>
            </div>
            <!-- /.modal-content -->
        </div>
        <!-- /.modal-dialog -->
    </div>
    <div class="modal fade" id="add_note_modal">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span></button>
                    <h4 class="modal-title"><?php echo e(trans_choice('general.add',1)); ?> <?php echo e(trans_choice('general.note',1)); ?></h4>
                </div>
                <form method="post" action="<?php echo e(url('grant/'.$grant->id.'/note/store')); ?>"
                      class="form-horizontal "
                      enctype="multipart/form-data" id="add_note_form">
                    <?php echo e(csrf_field()); ?>

                    <div class="modal-body">

                        <div class="form-group">
                            <label for="note_notes"
                                   class="control-label col-md-3"><?php echo e(trans_choice('general.note',1)); ?></label>
                            <div class="col-md-9">
       <textarea name="notes" class="form-control"
                 id="note_notes" rows="3" required><?php echo e(old('notes')); ?></textarea>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-default pull-left"
                                data-dismiss="modal"><?php echo e(trans_choice('general.close',1)); ?></button>
                        <button type="submit" class="btn btn-primary"><?php echo e(trans_choice('general.save',1)); ?></button>
                    </div>
                </form>
            </div>
            <!-- /.modal-content -->
        </div>
        <!-- /.modal-dialog -->
    </div>
    <div class="modal fade" id="view_note">
        <div class="modal-dialog">
            <div class="modal-content">
            </div>
            <!-- /.modal-content -->
        </div>
        <!-- /.modal-dialog -->
    </div>
    <div class="modal fade" id="edit_note">
        <div class="modal-dialog">
            <div class="modal-content">
            </div>
            <!-- /.modal-content -->
        </div>
        <!-- /.modal-dialog -->
    </div>
    <div class="modal fade" id="add_collateral_modal">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span></button>
                    <h4 class="modal-title"><?php echo e(trans_choice('general.add',1)); ?> <?php echo e(trans_choice('general.collateral',1)); ?></h4>
                </div>
                <form method="post" action="<?php echo e(url('grant/'.$grant->id.'/collateral/store')); ?>"
                      class="form-horizontal"
                      enctype="multipart/form-data" id="add_collateral_form">
                    <?php echo e(csrf_field()); ?>

                    <div class="modal-body">
                        <div class="form-group">
                            <label for="collateral_type_id"
                                   class="control-label col-md-3"><?php echo e(trans_choice('general.type',1)); ?></label>
                            <div class="col-md-9">
                                <select name="collateral_type_id" class="select2 form-control"
                                        id="collateral_type_id" required>
                                    <option></option>
                                    <?php $__currentLoopData = \App\Models\CollateralType::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($key->id); ?>"><?php echo e($key->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="value"
                                   class="control-label col-md-3"><?php echo e(trans_choice('general.value',1)); ?></label>
                            <div class="col-md-9">
                                <input type="number" name="value" class="form-control"
                                       value="<?php echo e(old('value')); ?>"
                                       required id="value">
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="description"
                                   class="control-label col-md-3"><?php echo e(trans_choice('general.description',1)); ?></label>
                            <div class="col-md-9">
                                <input type="text" name="description" class="form-control"
                                       value="<?php echo e(old('description')); ?>"
                                       required id="description">
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="serial"
                                   class="control-label col-md-3"><?php echo e(trans_choice('general.serial',1)); ?></label>
                            <div class="col-md-9">
                                <input type="text" name="serial" class="form-control"
                                       value="<?php echo e(old('serial')); ?>"
                                       required id="serial">
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-default pull-left"
                                data-dismiss="modal"><?php echo e(trans_choice('general.close',1)); ?></button>
                        <button type="submit" class="btn btn-primary"><?php echo e(trans_choice('general.save',1)); ?></button>
                    </div>
                </form>
            </div>
            <!-- /.modal-content -->
        </div>
        <!-- /.modal-dialog -->
    </div>
    <div class="modal fade" id="view_collateral">
        <div class="modal-dialog">
            <div class="modal-content">
            </div>
            <!-- /.modal-content -->
        </div>
        <!-- /.modal-dialog -->
    </div>
    <div class="modal fade" id="edit_collateral">
        <div class="modal-dialog">
            <div class="modal-content">
            </div>
            <!-- /.modal-content -->
        </div>
        <!-- /.modal-dialog -->
    </div>

    <div class="modal fade" id="add_guarantor_modal">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span></button>
                    <h4 class="modal-title"><?php echo e(trans_choice('general.add',1)); ?> <?php echo e(trans_choice('general.guarantor',1)); ?></h4>
                </div>
                <form method="post" action="<?php echo e(url('grant/'.$grant->id.'/guarantor/store')); ?>"
                      class="form-horizontal"
                      enctype="multipart/form-data" id="add_guarantor_form">
                    <?php echo e(csrf_field()); ?>

                    <div class="modal-body">
                        <div class="form-group">
                            <label for="is_client"
                                   class="control-label col-md-3"><?php echo e(trans_choice('general.existing',1)); ?> <?php echo e(trans_choice('general.client',1)); ?></label>
                            <div class="col-md-9">
                                <select name="is_client" class="select2 form-control"
                                        id="is_client" required>
                                    <option value="0"><?php echo e(trans_choice('general.no',1)); ?></option>
                                    <option value="1" selected><?php echo e(trans_choice('general.yes',1)); ?></option>
                                </select>
                            </div>
                        </div>
                        <div class="" id="clients_div" style="">
                            <div class="form-group">
                                <label for="guarantor_client_id"
                                       class="control-label col-md-3"><?php echo e(trans_choice('general.client',1)); ?></label>
                                <div class="col-md-9">
                                    <select name="client_id" class="form-control select2" id="guarantor_client_id">
                                        <option></option>
                                        <?php $__currentLoopData = \App\Models\Client::where('status', 'active')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($key->id); ?>">
                                                <?php if($key->client_type=="individual"): ?>
                                                    <?php echo e($key->first_name); ?> <?php echo e($key->middle_name); ?> <?php echo e($key->last_name); ?>

                                                    (<?php echo e($key->account_no); ?>)
                                                <?php else: ?>
                                                    <?php echo e($key->full_name); ?> (<?php echo e($key->account_no); ?>

                                                    )
                                                <?php endif; ?>
                                            </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="lock_funds"
                                       class="control-label col-md-3"><?php echo e(trans_choice('general.lock_funds',1)); ?></label>
                                <div class="col-md-9">
                                    <select name="lock_funds" class="select2 form-control"
                                            id="lock_funds">
                                        <option value="0" selected><?php echo e(trans_choice('general.no',1)); ?></option>
                                        <option value="1"><?php echo e(trans_choice('general.yes',1)); ?></option>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="client_relationship_id"
                                   class="control-label col-md-3"><?php echo e(trans_choice('general.relationship',1)); ?></label>
                            <div class="col-md-9">
                                <select name="client_relationship_id" class="select2 form-control"
                                        id="client_relationship_id" required>
                                    <option></option>
                                    <?php $__currentLoopData = \App\Models\ClientRelationship::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($key->id); ?>"><?php echo e($key->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>
                        <div id="new_client_div">
                            <div class="form-group">
                                <label for="guarantor_first_name"
                                       class="control-label col-md-3"><?php echo e(trans_choice('general.first_name',1)); ?></label>
                                <div class="col-md-9">
                                    <input type="text" name="first_name" class="form-control"
                                           value="<?php echo e(old('first_name')); ?>"
                                           required id="guarantor_first_name">
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="guarantor_middle_name"
                                       class="control-label col-md-3"><?php echo e(trans_choice('general.middle_name',1)); ?></label>
                                <div class="col-md-9">
                                    <input type="text" name="middle_name" class="form-control"
                                           value="<?php echo e(old('middle_name')); ?>"
                                           id="guarantor_middle_name">
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="guarantor_last_name"
                                       class="control-label col-md-3"><?php echo e(trans_choice('general.last_name',1)); ?></label>
                                <div class="col-md-9">
                                    <input type="text" name="last_name" class="form-control"
                                           value="<?php echo e(old('last_name')); ?>"
                                           required id="guarantor_last_name">
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="guarantor_mobile"
                                       class="control-label col-md-3"><?php echo e(trans_choice('general.mobile',1)); ?></label>
                                <div class="col-md-9">
                                    <input type="text" name="mobile" class="form-control"
                                           value="<?php echo e(old('mobile')); ?>"
                                           id="guarantor_mobile">
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="guarantor_gender"
                                       class="control-label col-md-3"><?php echo e(trans_choice('general.gender',1)); ?></label>
                                <div class="col-md-9">
                                    <select name="gender" class="form-control" id="guarantor_gender">
                                        <option value="male"><?php echo e(trans('general.male')); ?></option>
                                        <option value="female"><?php echo e(trans('general.female')); ?></option>
                                    </select>
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="guarantor_address"
                                       class="control-label col-md-3"><?php echo e(trans_choice('general.address',1)); ?></label>
                                <div class="col-md-9">
                                    <input type="text" name="guarantor_address" class="form-control"
                                           value=""
                                           id="guarantor_address">
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="guarantor_amount"
                                   class="control-label col-md-3"><?php echo e(trans_choice('general.amount',1)); ?></label>
                            <div class="col-md-9">
                                <input type="number" name="amount" class="form-control"
                                       value="<?php echo e(old('amount')); ?>"
                                       required id="guarantor_amount">
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-default pull-left"
                                data-dismiss="modal"><?php echo e(trans_choice('general.close',1)); ?></button>
                        <button type="submit" class="btn btn-primary"><?php echo e(trans_choice('general.save',1)); ?></button>
                    </div>
                </form>
            </div>
            <!-- /.modal-content -->
        </div>
        <!-- /.modal-dialog -->
    </div>
    <div class="modal fade" id="view_guarantor">
        <div class="modal-dialog">
            <div class="modal-content">
            </div>
            <!-- /.modal-content -->
        </div>
        <!-- /.modal-dialog -->
    </div>
    <div class="modal fade" id="edit_guarantor">
        <div class="modal-dialog">
            <div class="modal-content">
            </div>
            <!-- /.modal-content -->
        </div>
        <!-- /.modal-dialog -->
    </div>


<?php $__env->stopSection(); ?>
<?php $__env->startSection('footer-scripts'); ?>
    <script>
        if ($("#is_client").val() == 1) {
            $("#clients_div").show();
            $("#new_client_div").hide();
            $("#guarantor_client_id").attr('required', 'required');
            $("#guarantor_first_name").removeAttr('required');
            $("#guarantor_last_name").removeAttr('required');
            $("#guarantor_mobile").removeAttr('required');
        } else if ($("#is_client").val() == 0) {
            $("#clients_div").hide();
            $("#new_client_div").show();
            $("#guarantor_client_id").removeAttr('required');
            $("#guarantor_first_name").attr('required', 'required');
            $("#guarantor_last_name").attr('required', 'required');
            $("#guarantor_mobile").attr('required', 'required');
        } else {
            $("#clients_div").hide();
            $("#clients_div").hide();
        }
        $("#is_client").change(function (e) {
            if ($("#is_client").val() == 1) {
                $("#clients_div").show();
                $("#new_client_div").hide();
                $("#guarantor_client_id").attr('required', 'required');
                $("#guarantor_first_name").removeAttr('required');
                $("#guarantor_last_name").removeAttr('required');
                $("#guarantor_mobile").removeAttr('required');
            } else if ($("#is_client").val() == 0) {
                $("#clients_div").hide();
                $("#new_client_div").show();
                $("#guarantor_client_id").removeAttr('required');
                $("#guarantor_first_name").attr('required', 'required');
                $("#guarantor_last_name").attr('required', 'required');
                $("#guarantor_mobile").attr('required', 'required');
            } else {
                $("#clients_div").hide();
                $("#clients_div").hide();
            }
        });
        $('#view_note').on('shown.bs.modal', function (e) {
            var id = $(e.relatedTarget).data('id');
            $.ajax({
                type: 'GET',
                url: "<?php echo url('grant/note'); ?>/" + id + "/show",
                success: function (data) {
                    $(e.currentTarget).find(".modal-content").html(data);
                }
            });
        });
        $('#edit_note').on('shown.bs.modal', function (e) {
            var id = $(e.relatedTarget).data('id');
            $.ajax({
                type: 'GET',
                url: "<?php echo url('grant/note'); ?>/" + id + "/edit",
                success: function (data) {
                    $(e.currentTarget).find(".modal-content").html(data);
                }
            });
        })
        $('#view_collateral').on('shown.bs.modal', function (e) {
            var id = $(e.relatedTarget).data('id');
            $.ajax({
                type: 'GET',
                url: "<?php echo url('grant/collateral'); ?>/" + id + "/show",
                success: function (data) {
                    $(e.currentTarget).find(".modal-content").html(data);
                }
            });
        });
        $('#edit_collateral').on('shown.bs.modal', function (e) {
            var id = $(e.relatedTarget).data('id');
            $.ajax({
                type: 'GET',
                url: "<?php echo url('grant/collateral'); ?>/" + id + "/edit",
                success: function (data) {
                    $(e.currentTarget).find(".modal-content").html(data);
                }
            });
        });
        $('#view_guarantor').on('shown.bs.modal', function (e) {
            var id = $(e.relatedTarget).data('id');
            $.ajax({
                type: 'GET',
                url: "<?php echo url('grant/guarantor'); ?>/" + id + "/show",
                success: function (data) {
                    $(e.currentTarget).find(".modal-content").html(data);
                }
            });
        });
        $('#edit_guarantor').on('shown.bs.modal', function (e) {
            var id = $(e.relatedTarget).data('id');
            $.ajax({
                type: 'GET',
                url: "<?php echo url('grant/guarantor'); ?>/" + id + "/edit",
                success: function (data) {
                    $(e.currentTarget).find(".modal-content").html(data);
                }
            });
        });
        $("#add_document_form").validate();
        $("#add_collateral_form").validate();
        $("#add_guarantor_form").validate();
        $("#add_note_form").validate();
        $("#approve_grant_form").validate();
        $("#decline_grant_form").validate();
        $("#add_charge_form").validate();
        $("#waive_interest_form").validate();
        $("#write_off_grant_form").validate();
        $('#data-table').DataTable({
            dom: 'frtip',
            "paging": true,
            "lengthChange": true,
            "displayLength": 15,
            "searching": true,
            "ordering": true,
            "info": true,
            "autoWidth": true,
            "order": [[4, "desc"]],
            "columnDefs": [
                {"orderable": false, "targets": []}
            ],
            "language": {
                "lengthMenu": "<?php echo e(trans('general.lengthMenu')); ?>",
                "zeroRecords": "<?php echo e(trans('general.zeroRecords')); ?>",
                "info": "<?php echo e(trans('general.info')); ?>",
                "infoEmpty": "<?php echo e(trans('general.infoEmpty')); ?>",
                "search": "<?php echo e(trans('general.search')); ?>",
                "infoFiltered": "<?php echo e(trans('general.infoFiltered')); ?>",
                "paginate": {
                    "first": "<?php echo e(trans('general.first')); ?>",
                    "last": "<?php echo e(trans('general.last')); ?>",
                    "next": "<?php echo e(trans('general.next')); ?>",
                    "previous": "<?php echo e(trans('general.previous')); ?>"
                }
            },
            responsive: false
        });
        $('#repayments-data-table').DataTable({
            dom: 'frtip',
            "paging": true,
            "lengthChange": true,
            "displayLength": 15,
            "searching": true,
            "ordering": true,
            "info": true,
            "autoWidth": true,
            "order": [[1, "asc"]],
            "columnDefs": [
                {"orderable": false, "targets": []}
            ],
            "language": {
                "lengthMenu": "<?php echo e(trans('general.lengthMenu')); ?>",
                "zeroRecords": "<?php echo e(trans('general.zeroRecords')); ?>",
                "info": "<?php echo e(trans('general.info')); ?>",
                "infoEmpty": "<?php echo e(trans('general.infoEmpty')); ?>",
                "search": "<?php echo e(trans('general.search')); ?>",
                "infoFiltered": "<?php echo e(trans('general.infoFiltered')); ?>",
                "paginate": {
                    "first": "<?php echo e(trans('general.first')); ?>",
                    "last": "<?php echo e(trans('general.last')); ?>",
                    "next": "<?php echo e(trans('general.next')); ?>",
                    "previous": "<?php echo e(trans('general.previous')); ?>"
                }
            },
            responsive: false
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>