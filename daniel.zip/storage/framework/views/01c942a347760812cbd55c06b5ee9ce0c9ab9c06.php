<?php $__env->startSection('title'); ?>
    <?php echo e(trans_choice('general.edit',1)); ?> <?php echo e(trans_choice('general.grant',1)); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="box box-primary">
        <div class="box-header with-border">
            <h3 class="box-title"><?php echo e(trans_choice('general.edit',1)); ?> <?php echo e(trans_choice('general.grant',1)); ?></h3>

            <div class="box-tools pull-right">
                <button onclick="window.history.back()" class="btn btn-info btn-sm">
                    <?php echo e(trans_choice('general.cancel',1)); ?>

                </button>
            </div>
        </div>
        <form method="post" action="<?php echo e(url('grant/'.$grant->id.'/update')); ?>"
              class="form-horizontal"
              enctype="multipart/form-data">
            <?php echo e(csrf_field()); ?>

            <div class="box-body">
                <div class="form-group">
                    <label for="grant_officer_id"
                           class="control-label col-md-2">
                        <?php echo e(trans_choice('general.grant',1)); ?> <?php echo e(trans_choice('general.officer',1)); ?>

                        <i class="fa fa-question-circle" data-toggle="tooltip"
                           data-title="The financial institution representative who has responsibility for, and interacts with, the client/group associated with a grant account"></i>
                    </label>
                    <div class="col-md-3">
                        <select name="grant_officer_id" class="form-control select2" id="grant_officer_id" required>
                            <option></option>
                            <?php $__currentLoopData = \App\Models\User::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if(!Sentinel::findUserById($key->id)->inRole('client')): ?>
                                    <option value="<?php echo e($key->id); ?>" <?php if($grant->grant_officer_id==$key->id): ?> selected <?php endif; ?>><?php echo e($key->first_name); ?> <?php echo e($key->last_name); ?></option>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
                <div class="form-group">
                    <label for="currency_id"
                           class="control-label col-md-2"><?php echo e(trans_choice('general.currency',1)); ?>

                        <i class="fa fa-question-circle" data-toggle="tooltip"
                           data-title="The currency in which the grant will be disbursed."></i>
                    </label>
                    <div class="col-md-3">
                        <select name="currency_id" class="form-control select2" id="currency_id" required>
                            <option></option>
                            <?php $__currentLoopData = \App\Models\Currency::where('active',1)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($key->id); ?>"
                                        <?php if($grant->currency_id==$key->id): ?> selected <?php endif; ?>><?php echo e($key->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
                <div class="form-group">
                    <label for="decimals"
                           class="control-label col-md-2"><?php echo e(trans_choice('general.decimal',2)); ?>

                        <i class="fa fa-question-circle" data-toggle="tooltip"
                           data-title="The number of decimal places to be used to track and report on grants."></i>
                    </label>
                    <div class="col-md-3">
                        <input type="number" name="decimals" class="form-control"
                               value="<?php echo e($grant->decimals); ?>"
                               required id="decimals">
                    </div>
                </div>
                <div class="form-group">
                    <label for="amount"
                           class="control-label col-md-2"><?php echo e(trans_choice('general.amount',1)); ?>

                    </label>
                    <div class="col-md-3">
                        <input type="number" name="amount" class="form-control" value="<?php echo e($grant->amount); ?>"
                               required id="amount">
                    </div>
                </div>
                <div class="form-group">
                    <label for="external_id"
                           class="control-label col-md-2"><?php echo e(trans_choice('general.external_id',1)); ?></label>
                    <div class="col-md-3">
                        <input type="text" name="external_id" class="form-control"
                               value="<?php echo e($grant->external_id); ?>"
                               id="external_id">
                    </div>
                </div>
                <div class="form-group">
                    <label for="created_date"
                           class="control-label col-md-2"><?php echo e(trans_choice('general.created',1)); ?> <?php echo e(trans_choice('general.date',1)); ?></label>
                    <div class="col-md-3">
                        <input type="text" name="created_date" class="form-control date-picker"
                               value="<?php echo e($grant->created_date); ?>"
                               id="created_date">
                    </div>
                </div>
                <div class="form-group">
                    <label for="notes"
                           class="control-label col-md-2"><?php echo e(trans_choice('general.note',2)); ?></label>
                    <div class="col-md-8">
                        <textarea name="notes" class="form-control "
                                  placeholder=""
                                  id="notes" rows="3"><?php echo e($grant->notes); ?></textarea>
                    </div>
                </div>
                <?php if(\App\Models\Setting::where('setting_key','enable_custom_fields')->first()->setting_value==1): ?>
                    <?php $__currentLoopData = \App\Models\CustomField::where('category','grants')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="form-group">
                            <label for="notes"
                                   class="control-label col-md-2"><?php echo e($key->name); ?></label>
                            <div class="col-md-8">
                                <?php if($key->field_type=="number"): ?>
                                    <input type="number" class="form-control" name="custom_field_<?php echo e($key->id); ?>"
                                           <?php if($key->required==1): ?> required
                                           <?php endif; ?> value="<?php if(!empty(\App\Models\CustomFieldMeta::where('custom_field_id',$key->id)->where('parent_id',$grant->id)->where('category','grants')->first())): ?><?php echo e(\App\Models\CustomFieldMeta::where('custom_field_id',$key->id)->where('parent_id',$grant->id)->where('category','grants')->first()->name); ?> <?php endif; ?>">
                                <?php endif; ?>
                                <?php if($key->field_type=="textfield"): ?>
                                    <input type="text" class="form-control" name="custom_field_<?php echo e($key->id); ?>"
                                           <?php if($key->required==1): ?> required
                                           <?php endif; ?> value="<?php if(!empty(\App\Models\CustomFieldMeta::where('custom_field_id',$key->id)->where('parent_id',$grant->id)->where('category','grants')->first())): ?><?php echo e(\App\Models\CustomFieldMeta::where('custom_field_id',$key->id)->where('parent_id',$grant->id)->where('category','grants')->first()->name); ?> <?php endif; ?>">
                                <?php endif; ?>
                                <?php if($key->field_type=="date"): ?>
                                    <input type="text" class="form-control date-picker" name="custom_field_<?php echo e($key->id); ?>"
                                           <?php if($key->required==1): ?> required
                                           <?php endif; ?> value="<?php if(!empty(\App\Models\CustomFieldMeta::where('custom_field_id',$key->id)->where('parent_id',$grant->id)->where('category','grants')->first())): ?><?php echo e(\App\Models\CustomFieldMeta::where('custom_field_id',$key->id)->where('parent_id',$grant->id)->where('category','grants')->first()->name); ?> <?php endif; ?>">
                                <?php endif; ?>
                                <?php if($key->field_type=="textarea"): ?>
                                    <textarea class="form-control" name="custom_field_<?php echo e($key->id); ?>"
                                              <?php if($key->required==1): ?> required <?php endif; ?>><?php if(!empty(\App\Models\CustomFieldMeta::where('custom_field_id',$key->id)->where('parent_id',$grant->id)->where('category','grants')->first())): ?><?php echo e(\App\Models\CustomFieldMeta::where('custom_field_id',$key->id)->where('parent_id',$grant->id)->where('category','grants')->first()->name); ?> <?php endif; ?></textarea>
                                <?php endif; ?>
                                <?php if($key->field_type=="decimal"): ?>
                                    <input type="text" class="form-control touchspin" name="custom_field_<?php echo e($key->id); ?>"
                                           <?php if($key->required==1): ?> required
                                           <?php endif; ?> value="<?php if(!empty(\App\Models\CustomFieldMeta::where('custom_field_id',$key->id)->where('parent_id',$grant->id)->where('category','grants')->first())): ?><?php echo e(\App\Models\CustomFieldMeta::where('custom_field_id',$key->id)->where('parent_id',$grant->id)->where('category','grants')->first()->name); ?> <?php endif; ?>">
                                <?php endif; ?>
                                <?php if($key->field_type=="select"): ?>
                                    <select class="form-control touchspin" name="custom_field_<?php echo e($key->id); ?>"
                                            <?php if($key->required==1): ?> required <?php endif; ?>>
                                        <?php if($key->required!=1): ?>
                                            <option value=""></option>
                                        <?php else: ?>
                                            <option value="" disabled selected>Select...</option>
                                        <?php endif; ?>
                                        <?php $__currentLoopData = explode(',',$key->select_values); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if(!empty(\App\Models\CustomFieldMeta::where('custom_field_id',$key->id)->where('parent_id',$grant->id)->where('category','grants')->first())): ?>
                                                <?php if(\App\Models\CustomFieldMeta::where('custom_field_id',$key->id)->where('parent_id',$grant->id)->where('category','grants')->first()->name==$v): ?>
                                                    <option selected><?php echo e($v); ?></option>
                                                <?php else: ?>
                                                    <option><?php echo e($v); ?></option>
                                                <?php endif; ?>
                                            <?php else: ?>
                                                <option><?php echo e($v); ?></option>
                                            <?php endif; ?>

                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                <?php endif; ?>
                                <?php if($key->field_type=="radiobox"): ?>
                                    <?php $__currentLoopData = explode(',',$key->radio_box_values); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="radio">
                                            <label>
                                                <?php if(!empty(\App\Models\CustomFieldMeta::where('custom_field_id',$key->id)->where('parent_id',$grant->id)->where('category','grants')->first())): ?>
                                                    <?php if(\App\Models\CustomFieldMeta::where('custom_field_id',$key->id)->where('parent_id',$grant->id)->where('category','grants')->first()->name==$v): ?>
                                                        <input type="radio" name="custom_field_<?php echo e($key->id); ?>"
                                                               id="<?php echo e($key->id); ?>" value="<?php echo e($v); ?>"
                                                               <?php if($key->required==1): ?> required <?php endif; ?> checked>
                                                    <?php else: ?>
                                                        <input type="radio" name="custom_field_<?php echo e($key->id); ?>"
                                                               id="<?php echo e($key->id); ?>" value="<?php echo e($v); ?>"
                                                               <?php if($key->required==1): ?> required <?php endif; ?>>
                                                    <?php endif; ?>
                                                <?php else: ?>
                                                    <input type="radio" name="custom_field_<?php echo e($key->id); ?>"
                                                           id="<?php echo e($key->id); ?>" value="<?php echo e($v); ?>"
                                                           <?php if($key->required==1): ?> required <?php endif; ?>>
                                                <?php endif; ?>

                                                <b><?php echo e($v); ?></b>
                                            </label>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                                <?php if($key->field_type=="checkbox"): ?>
                                    <?php if(!empty(\App\Models\CustomFieldMeta::where('custom_field_id',$key->id)->where('parent_id',$grant->id)->where('category','grants')->first())): ?>
                                        <?php $c = unserialize(\App\Models\CustomFieldMeta::where('custom_field_id',
                                            $key->id)->where('parent_id', $grant->id)->where('category',
                                            'grants')->first()->name); ?>

                                        <?php $__currentLoopData = explode(',',$key->checkbox_values); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="checkbox">
                                                <label>
                                                    <?php if(array_key_exists($v,$c)): ?>
                                                        <?php if($c[$v]==$v): ?>
                                                            <input type="checkbox"
                                                                   name="custom_field_<?php echo e($key->id); ?>[<?php echo e($v); ?>]"
                                                                   id="<?php echo e($key->id); ?>"
                                                                   value="<?php echo e($v); ?>"
                                                                   <?php if($key->required==1): ?> required <?php endif; ?> checked>
                                                        <?php else: ?>
                                                            <input type="checkbox"
                                                                   name="custom_field_<?php echo e($key->id); ?>[<?php echo e($v); ?>]"
                                                                   id="<?php echo e($key->id); ?>"
                                                                   value="<?php echo e($v); ?>"
                                                                   <?php if($key->required==1): ?> required <?php endif; ?>>
                                                        <?php endif; ?>
                                                    <?php else: ?>
                                                        <input type="checkbox" name="custom_field_<?php echo e($key->id); ?>[<?php echo e($v); ?>]"
                                                               id="<?php echo e($key->id); ?>"
                                                               value="<?php echo e($v); ?>"
                                                               <?php if($key->required==1): ?> required <?php endif; ?>>
                                                    <?php endif; ?>
                                                    <b><?php echo e($v); ?></b>
                                                </label>
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php else: ?>
                                        <?php $__currentLoopData = explode(',',$key->checkbox_values); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="checkbox">
                                                <label>
                                                    <input type="checkbox" name="custom_field_<?php echo e($key->id); ?>[<?php echo e($v); ?>]"
                                                           id="<?php echo e($key->id); ?>"
                                                           value="<?php echo e($v); ?>"
                                                           <?php if($key->required==1): ?> required <?php endif; ?>>
                                                    <b><?php echo e($v); ?></b>
                                                </label>
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                <?php endif; ?>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </div>
            <div class="box-footer">
                <div class="heading-elements">
                    <button type="submit" class="btn btn-primary pull-right"><?php echo e(trans_choice('general.save',1)); ?></button>
                </div>
            </div>
        </form>
        <?php $__env->stopSection(); ?>
        <?php $__env->startSection('footer-scripts'); ?>
            <script>
                $(".form-horizontal").validate({
                    rules: {
                        field: {
                            required: true,
                            step: 10
                        }
                    }, highlight: function (element) {
                        $(element).closest('.form-group div').addClass('has-error');
                    },
                    unhighlight: function (element) {
                        $(element).closest('.form-group div').removeClass('has-error');
                    },
                    errorElement: 'span',
                    errorClass: 'help-block',
                    errorPlacement: function (error, element) {
                        if (element.parent('.input-group').length) {
                            error.insertAfter(element.parent());
                        } else {
                            error.insertAfter(element);
                        }
                    }
                });
            </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>