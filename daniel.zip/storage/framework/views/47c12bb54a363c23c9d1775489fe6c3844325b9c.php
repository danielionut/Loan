<?php $__env->startSection('title'); ?>
    <?php echo e(trans_choice('general.role',2)); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="box box-primary">
        <div class="box-header with-border">
            <h3 class="box-title"><?php echo e(trans_choice('general.role',2)); ?></h3>

            <div class="box-tools pull-right">
                <?php if(Sentinel::hasAccess('users.roles.create')): ?>
                    <a href="<?php echo e(url('user/role/create')); ?>" class="btn btn-info btn-sm">
                        <?php echo e(trans_choice('general.add',1)); ?> <?php echo e(trans_choice('general.role',1)); ?>

                    </a>
                <?php endif; ?>
            </div>
        </div>
        <div class="box-body  responsive">
            <table class="table table-bordered table-hover table-striped" id="">
                <thead>
                <tr>
                    <th><?php echo e(trans_choice('general.name',1)); ?></th>
                    <th><?php echo e(trans('general.slug')); ?></th>
                    <th><?php echo e(trans('general.time_limit')); ?></th>
                    <th><?php echo e(trans_choice('general.action',1)); ?></th>
                </tr>
                </thead>

                <tbody>
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <tr>
                        <td><?php echo e($key->name); ?></td>
                        <td><?php echo e($key->slug); ?></td>
                        <td>
                            <?php if($key->time_limit==1): ?>
                                <?php echo e(trans_choice('general.yes',1)); ?>

                            <?php endif; ?>
                            <?php if($key->time_limit==0): ?>
                                <?php echo e(trans_choice('general.no',1)); ?>

                            <?php endif; ?>

                        </td>
                        <td>
                            <div class="btn-group">

                                <button class="btn bg-blue btn-sm dropdown-toggle" type="button"
                                        data-toggle="dropdown"
                                        aria-expanded="false"><i
                                            class="fa fa-navicon"></i></button>
                                <ul class="dropdown-menu" role="menu">
                                    <?php if(Sentinel::hasAccess('users.roles.update')): ?>
                                        <li>
                                            <a href="<?php echo e(url('user/role/'.$key->id.'/edit')); ?>"><i
                                                        class="fa fa-edit"></i>
                                                <?php echo e(trans('general.edit')); ?></a>
                                        </li>
                                    <?php endif; ?>
                                    <?php if(Sentinel::hasAccess('users.roles.delete')): ?>
                                        <li>
                                            <a href="<?php echo e(url('user/role/'.$key->id.'/delete')); ?>"
                                               class="delete"><i
                                                        class="fa fa-trash"></i>
                                                <?php echo e(trans('general.delete')); ?></a>
                                        </li>
                                    <?php endif; ?>
                                </ul>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>