<?php $__env->startSection('title'); ?>
    Create Permission
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <style>
        .select2-container {
            width: 100% !important;
        }
    </style>
    <div class="panel panel-white">
        <div class="panel-heading">
            <h6 class="panel-title">Create Permission</h6>

        </div>
        <form method="post" action="<?php echo e(url('user/permission/store')); ?>" class="form">
            <?php echo e(csrf_field()); ?>

            <div class="panel-body">

                <div class="form-group">
                    <div class="form-line">
                        <label for="type"
                               class=""><?php echo e(trans_choice('general.type',1)); ?></label>
                        <select name="type" class="form-control" id="type">
                            <option value="0">Parent Permission</option>
                            <option value="1">Sub Permission</option>
                        </select>
                    </div>
                </div>
                <div class="form-group" id="parent">
                    <div class="form-line">
                        <label for="parent_id"
                               class="">Parent</label>
                        <select name="parent_id" class="form-control select2" id="parent_id">
                            <option value="0"></option>
                            <?php $__currentLoopData = \App\Models\Permission::where('parent_id', 0)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($permission->id); ?>"><?php echo e($permission->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
                <div class="form-group">
                    <div class="form-line">
                        <label for="name"
                               class=""><?php echo e(trans_choice('general.name',1)); ?></label>
                        <input type="text" name="name" class="form-control"
                               placeholder="<?php echo e(trans_choice('general.name',1)); ?>"
                               value="<?php echo e(old('name')); ?>"
                               required id="name">
                    </div>
                </div>
                <div class="form-group">
                    <div class="form-line">
                        <label for="slug"
                               class=""><?php echo e(trans_choice('general.slug',1)); ?></label>
                        <input type="text" name="slug" class="form-control"
                               placeholder="<?php echo e(trans_choice('general.slug',1)); ?>"
                               value="<?php echo e(old('slug')); ?>"
                               required id="slug">
                    </div>
                </div>
                <div class="form-group">
                    <div class="form-line">
                        <label for="description"
                               class=""><?php echo e(trans_choice('general.description',1)); ?></label>
                        <textarea name="description" class="form-control"
                                  placeholder="<?php echo e(trans_choice('general.description',1)); ?>"
                                  id="description" rows="3"><?php echo e(old('description')); ?></textarea>
                    </div>
                </div>

            </div>
            <!-- /.panel-body -->
            <div class="panel-footer">
                <button type="submit" class="btn btn-primary pull-right">Save</button>
            </div>
        </form>
    </div>
    <script>
        $(document).ready(function () {
            if ($('#type').val() == 0) {
                $('#parent').hide();
            } else {
                $('#parent').show();
            }
            $('#type').change(function () {
                if ($('#type').val() == 0) {
                    $('#parent').hide();
                } else {
                    $('#parent').show();
                }
            })
        })
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>