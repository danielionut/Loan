<aside class="main-sidebar">
    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">
        <!-- Sidebar user panel -->
        <div class="user-panel">
            <div class="pull-left image">
                <i class="fa fa-user" style="font-size: 60px"></i>
            </div>
            <div class="pull-left info">
                <p><?php echo e(Sentinel::getUser()->first_name); ?> <?php echo e(Sentinel::getUser()->last_name); ?></p>
                <a href="#"><i class="fa fa-circle text-success"></i> Online</a>
            </div>
        </div>
        <!-- /.search form -->
        <!-- sidebar menu: : style can be found in sidebar.less -->
        <ul class="sidebar-menu" data-widget="tree">

            <li class="<?php if(Request::is('dashboard')): ?> active <?php endif; ?>">
                <a href="<?php echo e(url('dashboard')); ?>">
                    <i class="fa fa-dashboard"></i> <span><?php echo e(trans_choice('general.dashboard',1)); ?></span>
                </a>
            </li>
            <?php if(Sentinel::hasAccess('offices')): ?>
                <li class="treeview <?php if(Request::is('office/*')): ?> active <?php endif; ?>">
                    <a href="#">
                        <i class="fa fa-briefcase"></i> <span><?php echo e(trans_choice('general.branch',2)); ?></span>
                        <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
                    </a>
                    <ul class="treeview-menu">
                        <?php if(Sentinel::hasAccess('offices.view')): ?>
                            <li><a href="<?php echo e(url('office/data')); ?>"><i
                                            class="fa fa-circle-o"></i> <?php echo e(trans_choice('general.view',1)); ?> <?php echo e(trans_choice('general.branch',2)); ?>

                                </a></li>
                        <?php endif; ?>
                        <?php if(Sentinel::hasAccess('offices.create')): ?>
                            <li><a href="<?php echo e(url('office/create')); ?>"><i
                                            class="fa fa-circle-o"></i> <?php echo e(trans_choice('general.add',1)); ?> <?php echo e(trans_choice('general.branch',1)); ?>

                                </a></li>
                        <?php endif; ?>
                    </ul>
                </li>
            <?php endif; ?>
            <?php if(Sentinel::hasAccess('clients')): ?>
                <li class="treeview <?php if(Request::is('client/*')): ?> active <?php endif; ?>
                <?php if(Request::is('group/*')): ?> active <?php endif; ?>">
                    <a href="#">
                        <i class="fa fa-users"></i> <span><?php echo e(trans_choice('general.client',2)); ?></span>
                        <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
                    </a>
                    <ul class="treeview-menu">
                        <?php if(Sentinel::hasAccess('clients.view')): ?>
                            <li><a href="<?php echo e(url('client/data')); ?>"><i
                                            class="fa fa-circle-o"></i> <?php echo e(trans_choice('general.view',1)); ?> <?php echo e(trans_choice('general.client',2)); ?>

                                </a></li>
                        <?php endif; ?>
                        <?php if(Sentinel::hasAccess('clients.pending_approval')): ?>
                            <li><a href="<?php echo e(url('client/pending_approval')); ?>"><i
                                            class="fa fa-circle-o"></i><?php echo e(trans_choice('general.client',2)); ?> <?php echo e(trans_choice('general.pending',1)); ?> <?php echo e(trans_choice('general.approval',2)); ?>

                                </a></li>
                        <?php endif; ?>
                        <?php if(Sentinel::hasAccess('clients.closed')): ?>
                            <li><a href="<?php echo e(url('client/closed')); ?>"><i
                                            class="fa fa-circle-o"></i><?php echo e(trans_choice('general.client',2)); ?> <?php echo e(trans_choice('general.closed',1)); ?>

                                </a></li>
                        <?php endif; ?>
                        <?php if(Sentinel::hasAccess('clients.closed')): ?>
                            <li><a href="<?php echo e(url('client/clients_inactive')); ?>"><i
                                            class="fa fa-circle-o"></i><?php echo e(trans_choice('general.client',2)); ?> <?php echo e(trans_choice('general.inactive',1)); ?>

                                </a></li>
                        <?php endif; ?>
                        <?php if(Sentinel::hasAccess('clients.view')): ?>
                            <li><a href="<?php echo e(url('client/declined')); ?>"><i
                                            class="fa fa-circle-o"></i><?php echo e(trans_choice('general.client',2)); ?> <?php echo e(trans_choice('general.declined',1)); ?>

                                </a></li>
                        <?php endif; ?>
                        <?php if(Sentinel::hasAccess('clients.create')): ?>
                            <li><a href="<?php echo e(url('client/create')); ?>"><i
                                            class="fa fa-circle-o"></i> <?php echo e(trans_choice('general.add',1)); ?> <?php echo e(trans_choice('general.client',1)); ?>

                                </a></li>
                        <?php endif; ?>
                        <?php if(Sentinel::hasAccess('groups')): ?>
                            <li><a href="<?php echo e(url('group/data')); ?>"><i
                                            class="fa fa-circle-o"></i> <?php echo e(trans_choice('general.view',1)); ?>  <?php echo e(trans_choice('general.group',2)); ?>

                                </a></li>
                        <?php endif; ?>
                        <?php if(Sentinel::hasAccess('groups.pending_approval')): ?>
                            <li><a href="<?php echo e(url('group/pending_approval')); ?>"><i
                                            class="fa fa-circle-o"></i><?php echo e(trans_choice('general.group',2)); ?> <?php echo e(trans_choice('general.pending',1)); ?> <?php echo e(trans_choice('general.approval',2)); ?>

                                </a></li>
                        <?php endif; ?>
                        <?php if(Sentinel::hasAccess('groups.view')): ?>
                            <li><a href="<?php echo e(url('group/groups_declined')); ?>"><i
                                            class="fa fa-circle-o"></i><?php echo e(trans_choice('general.group',2)); ?> <?php echo e(trans_choice('general.declined',1)); ?>

                                </a></li>
                        <?php endif; ?>
                        <?php if(Sentinel::hasAccess('groups.view')): ?>
                            <li><a href="<?php echo e(url('group/groups_closed')); ?>"><i
                                            class="fa fa-circle-o"></i><?php echo e(trans_choice('general.group',2)); ?> <?php echo e(trans_choice('general.closed',1)); ?>

                                </a></li>
                        <?php endif; ?>
                        <?php if(Sentinel::hasAccess('groups.create')): ?>
                            <li><a href="<?php echo e(url('group/create')); ?>"><i
                                            class="fa fa-circle-o"></i> <?php echo e(trans_choice('general.add',1)); ?>  <?php echo e(trans_choice('general.group',1)); ?>

                                </a></li>
                        <?php endif; ?>
                    </ul>
                </li>
            <?php endif; ?>
            <?php if(Sentinel::hasAccess('loans')): ?>
                <li class="treeview <?php if(Request::is('loan/*')): ?> active <?php endif; ?>">
                    <a href="#">
                        <i class="fa fa-money"></i> <span><?php echo e(trans_choice('general.loan',2)); ?></span>
                        <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
                    </a>
                    <ul class="treeview-menu">
                        <?php if(Sentinel::hasAccess('loans.view')): ?>
                            <li><a href="<?php echo e(url('loan/data')); ?>"><i
                                            class="fa fa-circle-o"></i> <?php echo e(trans_choice('general.active',2)); ?> <?php echo e(trans_choice('general.loan',2)); ?>

                                    <span class="pull-right-container">
                                        <span class="label label-info pull-right"><?php echo e(\App\Models\Loan::where('status','disbursed')->count()); ?></span>
                                    </span>
                                </a></li>
                        <?php endif; ?>
                        <?php if(Sentinel::hasAccess('loans.pending_approval')): ?>
                            <li>
                                <a href="<?php echo e(url('loan/pending_approval')); ?>"><i
                                            class="fa fa-circle-o"></i> <?php echo e(trans_choice('general.pending',1)); ?> <?php echo e(trans_choice('general.approval',1)); ?>

                                    <span class="pull-right-container">
                                        <span class="label label-warning pull-right"><?php echo e(\App\Models\Loan::where('status','pending')->count()); ?></span>
                                    </span>
                                </a>
                            </li>
                        <?php endif; ?>
                        <?php if(Sentinel::hasAccess('loans.awaiting_disbursement')): ?>
                            <li>
                                <a href="<?php echo e(url('loan/awaiting_disbursement')); ?>"><i
                                            class="fa fa-circle-o"></i> <?php echo e(trans_choice('general.awaiting',1)); ?> <?php echo e(trans_choice('general.disbursement',1)); ?>

                                    <span class="pull-right-container">
                                        <span class="label label-info pull-right"><?php echo e(\App\Models\Loan::where('status','approved')->count()); ?></span>
                                    </span>
                                </a>
                            </li>
                        <?php endif; ?>
                        <?php if(Sentinel::hasAccess('loans.declined')): ?>
                            <li>
                                <a href="<?php echo e(url('loan/loans_declined')); ?>"><i
                                            class="fa fa-circle-o"></i> <?php echo e(trans_choice('general.loan',2)); ?> <?php echo e(trans_choice('general.declined',1)); ?>

                                    <span class="pull-right-container">
                                        <span class="label label-danger pull-right"><?php echo e(\App\Models\Loan::where('status','declined')->count()); ?></span>
                                    </span>
                                </a>
                            </li>
                        <?php endif; ?>
                        <?php if(Sentinel::hasAccess('loans.written_off')): ?>
                            <li>
                                <a href="<?php echo e(url('loan/loans_written_off')); ?>"><i
                                            class="fa fa-circle-o"></i> <?php echo e(trans_choice('general.loan',2)); ?> <?php echo e(trans_choice('general.written_off',1)); ?>

                                    <span class="pull-right-container">
                                        <span class="label label-danger pull-right"><?php echo e(\App\Models\Loan::where('status','written_off')->count()); ?></span>
                                    </span>
                                </a>
                            </li>
                        <?php endif; ?>
                        <?php if(Sentinel::hasAccess('loans.closed')): ?>
                            <li>
                                <a href="<?php echo e(url('loan/loans_closed')); ?>"><i
                                            class="fa fa-circle-o"></i> <?php echo e(trans_choice('general.loan',2)); ?> <?php echo e(trans_choice('general.closed',1)); ?>

                                    <span class="pull-right-container">
                                        <span class="label label-success pull-right"><?php echo e(\App\Models\Loan::where('status','closed')->count()); ?></span>
                                    </span>
                                </a>
                            </li>
                        <?php endif; ?>
                        <?php if(Sentinel::hasAccess('loans.rescheduled')): ?>
                            <li>
                                <a href="<?php echo e(url('loan/loans_rescheduled')); ?>"><i
                                            class="fa fa-circle-o"></i> <?php echo e(trans_choice('general.loan',2)); ?> <?php echo e(trans_choice('general.rescheduled',1)); ?>

                                    <span class="pull-right-container">
                                        <span class="label label-success pull-right"><?php echo e(\App\Models\Loan::where('status','rescheduled')->count()); ?></span>
                                    </span>
                                </a>
                            </li>
                        <?php endif; ?>
                        <?php if(Sentinel::hasAccess('loans.create') && \App\Models\Setting::where('setting_key','allow_client_apply')->first()->setting_value==1): ?>
                            <li>
                                <a href="<?php echo e(url('loan/application/data')); ?>"><i
                                            class="fa fa-circle-o"></i> <?php echo e(trans_choice('general.loan',2)); ?> <?php echo e(trans_choice('general.application',2)); ?>

                                    <span class="pull-right-container">
                                        <span class="label label-warning pull-right"><?php echo e(\App\Models\LoanApplication::where('status','pending')->count()); ?></span>
                                    </span>
                                </a>
                            </li>
                        <?php endif; ?>
                        <?php if(Sentinel::hasAccess('loans.create')): ?>
                            <li><a href="<?php echo e(url('loan/create')); ?>"><i
                                            class="fa fa-circle-o"></i> <?php echo e(trans_choice('general.add',2)); ?> <?php echo e(trans_choice('general.loan',1)); ?>

                                </a></li>
                        <?php endif; ?>
                        <?php if(Sentinel::hasAccess('products.loan_products.view')): ?>
                            <li><a href="<?php echo e(url('loan/product/data')); ?>"><i
                                            class="fa fa-circle-o"></i> <?php echo e(trans_choice('general.manage',1)); ?> <?php echo e(trans_choice('general.loan',1)); ?> <?php echo e(trans_choice('general.product',2)); ?>

                                </a></li><?php endif; ?>

                        <?php if(Sentinel::hasAccess('loans.create')): ?>
                            <li><a href="<?php echo e(url('loan/calculator/create')); ?>"><i
                                            class="fa fa-circle-o"></i> <?php echo e(trans_choice('general.loan',1)); ?> <?php echo e(trans_choice('general.calculator',1)); ?>

                                </a></li>
                        <?php endif; ?>
                    </ul>
                </li>
            <?php endif; ?>
            <?php if(Sentinel::hasAccess('grants')): ?>
                <li class="treeview <?php if(Request::is('grant/*')): ?> active <?php endif; ?>">
                    <a href="#">
                        <i class="fa fa-money"></i> <span><?php echo e(trans_choice('general.grant',2)); ?></span>
                        <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
                    </a>
                    <ul class="treeview-menu">
                        <?php if(Sentinel::hasAccess('grants.view')): ?>
                            <li><a href="<?php echo e(url('grant/data')); ?>"><i
                                            class="fa fa-circle-o"></i> <?php echo e(trans_choice('general.disbursed',1)); ?> <?php echo e(trans_choice('general.grant',2)); ?>

                                    <span class="pull-right-container">
                                        <span class="label label-info pull-right"><?php echo e(\App\Models\Grant::where('status','disbursed')->count()); ?></span>
                                    </span>
                                </a></li>
                        <?php endif; ?>
                        <?php if(Sentinel::hasAccess('grants.pending_approval')): ?>
                            <li>
                                <a href="<?php echo e(url('grant/pending_approval')); ?>"><i
                                            class="fa fa-circle-o"></i> <?php echo e(trans_choice('general.pending',1)); ?> <?php echo e(trans_choice('general.approval',1)); ?>

                                    <span class="pull-right-container">
                                        <span class="label label-warning pull-right"><?php echo e(\App\Models\Grant::where('status','pending')->count()); ?></span>
                                    </span>
                                </a>
                            </li>
                        <?php endif; ?>
                        <?php if(Sentinel::hasAccess('grants.awaiting_disbursement')): ?>
                            <li>
                                <a href="<?php echo e(url('grant/awaiting_disbursement')); ?>"><i
                                            class="fa fa-circle-o"></i> <?php echo e(trans_choice('general.awaiting',1)); ?> <?php echo e(trans_choice('general.disbursement',1)); ?>

                                    <span class="pull-right-container">
                                        <span class="label label-info pull-right"><?php echo e(\App\Models\Grant::where('status','approved')->count()); ?></span>
                                    </span>
                                </a>
                            </li>
                        <?php endif; ?>
                        <?php if(Sentinel::hasAccess('grants.declined')): ?>
                            <li>
                                <a href="<?php echo e(url('grant/grants_declined')); ?>"><i
                                            class="fa fa-circle-o"></i> <?php echo e(trans_choice('general.grant',2)); ?> <?php echo e(trans_choice('general.declined',1)); ?>

                                    <span class="pull-right-container">
                                        <span class="label label-danger pull-right"><?php echo e(\App\Models\Grant::where('status','declined')->count()); ?></span>
                                    </span>
                                </a>
                            </li>
                        <?php endif; ?>
                        <?php if(Sentinel::hasAccess('grants.create')): ?>
                            <li><a href="<?php echo e(url('grant/create')); ?>"><i
                                            class="fa fa-circle-o"></i> <?php echo e(trans_choice('general.add',2)); ?> <?php echo e(trans_choice('general.grant',1)); ?>

                                </a></li>
                        <?php endif; ?>
                    </ul>
                </li>
            <?php endif; ?>
            <?php if(Sentinel::hasAccess('accounting')): ?>
                <li class="treeview <?php if(Request::is('accounting/*')): ?> active <?php endif; ?>">
                    <a href="#">
                        <i class="fa fa-money"></i> <span><?php echo e(trans_choice('general.accounting',1)); ?></span>
                        <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
                    </a>
                    <ul class="treeview-menu">
                        <?php if(Sentinel::hasAccess('accounting.gl_accounts.view')): ?>
                            <li><a href="<?php echo e(url('accounting/gl_account/data')); ?>"><i
                                            class="fa fa-circle-o"></i> <?php echo e(trans_choice('general.chart_of_account',2)); ?>

                                </a></li>
                        <?php endif; ?>
                        <?php if(Sentinel::hasAccess('accounting.journals.view')): ?>
                            <li><a href="<?php echo e(url('accounting/journal/data')); ?>"><i
                                            class="fa fa-circle-o"></i> <?php echo e(trans_choice('general.journal',2)); ?>

                                </a></li>
                        <?php endif; ?>
                        <?php if(Sentinel::hasAccess('accounting.journals.create')): ?>
                            <li><a href="<?php echo e(url('accounting/journal/create')); ?>"><i
                                            class="fa fa-circle-o"></i> <?php echo e(trans_choice('general.add',2)); ?> <?php echo e(trans_choice('general.journal',1)); ?> <?php echo e(trans_choice('general.entry',1)); ?>

                                </a></li>
                        <?php endif; ?>
                        <?php if(Sentinel::hasAccess('accounting.journals.reconciliation.view')): ?>
                            <li><a href="<?php echo e(url('accounting/reconciliation/data')); ?>"><i
                                            class="fa fa-circle-o"></i> <?php echo e(trans_choice('general.reconciliation',1)); ?>

                                </a></li>
                        <?php endif; ?>
                        <?php if(Sentinel::hasAccess('accounting.period.view')): ?>
                            <li><a href="<?php echo e(url('accounting/period/data')); ?>"><i
                                            class="fa fa-circle-o"></i> <?php echo e(trans_choice('general.close',1)); ?> <?php echo e(trans_choice('general.period',2)); ?>

                                </a></li>
                        <?php endif; ?>
                    </ul>
                </li>
            <?php endif; ?>
            <?php if(Sentinel::hasAccess('savings')): ?>
                <li class="treeview <?php if(Request::is('savings/*')): ?> active <?php endif; ?>">
                    <a href="#">
                        <i class="fa fa-bank"></i> <span><?php echo e(trans_choice('general.savings',2)); ?></span>
                        <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
                    </a>
                    <ul class="treeview-menu">
                        <?php if(Sentinel::hasAccess('savings.view')): ?>
                            <li><a href="<?php echo e(url('savings/data')); ?>"><i
                                            class="fa fa-circle-o"></i> <?php echo e(trans_choice('general.active',2)); ?> <?php echo e(trans_choice('general.savings',2)); ?>

                                </a></li>
                        <?php endif; ?>
                        <?php if(Sentinel::hasAccess('savings.pending_approval')): ?>
                            <li><a href="<?php echo e(url('savings/pending_approval')); ?>"><i
                                            class="fa fa-circle-o"></i> <?php echo e(trans_choice('general.pending',2)); ?> <?php echo e(trans_choice('general.approval',1)); ?>

                                </a></li>
                        <?php endif; ?>
                        <?php if(Sentinel::hasAccess('savings.closed')): ?>
                            <li><a href="<?php echo e(url('savings/savings_closed')); ?>"><i
                                            class="fa fa-circle-o"></i> <?php echo e(trans_choice('general.closed',2)); ?> <?php echo e(trans_choice('general.savings',2)); ?>

                                </a></li>
                        <?php endif; ?>
                        <?php if(Sentinel::hasAccess('savings.create')): ?>
                            <li><a href="<?php echo e(url('savings/create')); ?>"><i
                                            class="fa fa-circle-o"></i> <?php echo e(trans_choice('general.add',2)); ?> <?php echo e(trans_choice('general.savings',2)); ?> <?php echo e(trans_choice('general.account',1)); ?>

                                </a></li>
                        <?php endif; ?>
                        <?php if(Sentinel::hasAccess('products.savings_products.view')): ?>
                            <li><a href="<?php echo e(url('savings/product/data')); ?>"><i
                                            class="fa fa-circle-o"></i> <?php echo e(trans_choice('general.manage',2)); ?> <?php echo e(trans_choice('general.savings',2)); ?> <?php echo e(trans_choice('general.product',2)); ?>

                                </a></li>
                        <?php endif; ?>

                    </ul>
                </li>
            <?php endif; ?>
            <?php if(Sentinel::hasAccess('reports')): ?>
                <li class="treeview <?php if(Request::is('report/*')): ?> active <?php endif; ?>">
                    <a href="#">
                        <i class="fa fa-bar-chart"></i> <span><?php echo e(trans_choice('general.report',2)); ?></span>
                        <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
                    </a>
                    <ul class="treeview-menu">
                        <?php if(Sentinel::hasAccess('reports.client_reports')): ?>
                            <li><a href="<?php echo e(url('report/client_report')); ?>"><i
                                            class="fa fa-circle-o"></i> <?php echo e(trans_choice('general.client',1)); ?> <?php echo e(trans_choice('general.report',2)); ?>

                                </a></li>
                        <?php endif; ?>
                        <?php if(Sentinel::hasAccess('reports.loan_reports')): ?>
                            <li><a href="<?php echo e(url('report/loan_report')); ?>"><i
                                            class="fa fa-circle-o"></i> <?php echo e(trans_choice('general.loan',1)); ?> <?php echo e(trans_choice('general.report',2)); ?>

                                </a></li>
                        <?php endif; ?>
                        <?php if(Sentinel::hasAccess('reports.financial_reports')): ?>
                            <li><a href="<?php echo e(url('report/financial_report')); ?>"><i
                                            class="fa fa-circle-o"></i> <?php echo e(trans_choice('general.financial',1)); ?> <?php echo e(trans_choice('general.report',2)); ?>

                                </a></li>
                        <?php endif; ?>
                        <?php if(Sentinel::hasAccess('reports.company_reports')): ?>
                            <li class="hidden"><a href="<?php echo e(url('report/company_report')); ?>"><i
                                            class="fa fa-circle-o"></i> <?php echo e(trans_choice('general.organisation',1)); ?> <?php echo e(trans_choice('general.report',2)); ?>

                                </a></li>
                        <?php endif; ?>
                        <?php if(Sentinel::hasAccess('reports.savings_reports')): ?>
                            <li><a href="<?php echo e(url('report/savings_report')); ?>"><i
                                            class="fa fa-circle-o"></i> <?php echo e(trans_choice('general.savings',2)); ?> <?php echo e(trans_choice('general.report',2)); ?>

                                </a></li>
                        <?php endif; ?>
                        <?php if(Sentinel::hasAccess('reports.grant_reports')): ?>
                            <li><a href="<?php echo e(url('report/grant_report')); ?>"><i
                                            class="fa fa-circle-o"></i> <?php echo e(trans_choice('general.grant',1)); ?> <?php echo e(trans_choice('general.report',2)); ?>

                                </a></li>
                        <?php endif; ?>
                        <?php if(Sentinel::hasAccess('reports.reports_scheduler.view')): ?>
                            <li class="hidden"><a href="<?php echo e(url('report/report_scheduler/data')); ?>"><i
                                            class="fa fa-circle-o"></i> <?php echo e(trans_choice('general.report',1)); ?> <?php echo e(trans_choice('general.scheduler',1)); ?>

                                </a></li>
                        <?php endif; ?>

                    </ul>
                </li>
            <?php endif; ?>
            <?php if(Sentinel::hasAccess('communication')): ?>
                <li class="treeview <?php if(Request::is('communication/*')): ?> active <?php endif; ?>">
                    <a href="#">
                        <i class="fa fa-envelope"></i> <span><?php echo e(trans_choice('general.communication',2)); ?></span>
                        <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
                    </a>
                    <ul class="treeview-menu">
                        <?php if(Sentinel::hasAccess('communication.view')): ?>
                            <li><a href="<?php echo e(url('communication/data')); ?>"><i
                                            class="fa fa-circle-o"></i> <?php echo e(trans_choice('general.view',1)); ?> <?php echo e(trans_choice('general.campaign',2)); ?>

                                </a></li>
                        <?php endif; ?>
                        <?php if(Sentinel::hasAccess('communication.create')): ?>
                            <li><a href="<?php echo e(url('communication/create')); ?>"><i
                                            class="fa fa-circle-o"></i> <?php echo e(trans_choice('general.create',1)); ?> <?php echo e(trans_choice('general.campaign',1)); ?>

                                </a></li>
                        <?php endif; ?>
                    </ul>
                </li>
            <?php endif; ?>
            <?php if(Sentinel::hasAccess('assets')): ?>
                <li class="treeview <?php if(Request::is('asset/*')): ?> active <?php endif; ?>">
                    <a href="#">
                        <i class="fa fa-building"></i> <span><?php echo e(trans_choice('general.asset',2)); ?></span>
                        <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
                    </a>
                    <ul class="treeview-menu">
                        <?php if(Sentinel::hasAccess('assets.view')): ?>
                            <li><a href="<?php echo e(url('asset/data')); ?>"><i
                                            class="fa fa-circle-o"></i> <?php echo e(trans_choice('general.view',2)); ?> <?php echo e(trans_choice('general.asset',2)); ?>

                                </a></li>
                        <?php endif; ?>
                        <?php if(Sentinel::hasAccess('assets.create')): ?>
                            <li><a href="<?php echo e(url('asset/create')); ?>"><i
                                            class="fa fa-circle-o"></i> <?php echo e(trans_choice('general.add',2)); ?> <?php echo e(trans_choice('general.asset',1)); ?>

                                </a></li>
                        <?php endif; ?>
                        <?php if(Sentinel::hasAccess('assets.types.view')): ?>
                            <li><a href="<?php echo e(url('asset/type/data')); ?>"><i
                                            class="fa fa-circle-o"></i> <?php echo e(trans_choice('general.manage',1)); ?> <?php echo e(trans_choice('general.asset',1)); ?> <?php echo e(trans_choice('general.type',2)); ?>

                                </a></li>
                        <?php endif; ?>
                    </ul>
                </li>
            <?php endif; ?>
            <?php if(Sentinel::hasAccess('expenses')): ?>
                <li class="treeview <?php if(Request::is('expense/*')): ?> active <?php endif; ?>">
                    <a href="#">
                        <i class="fa fa-share"></i> <span><?php echo e(trans_choice('general.expense',2)); ?></span>
                        <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
                    </a>
                    <ul class="treeview-menu">
                        <?php if(Sentinel::hasAccess('expenses.view')): ?>
                            <li><a href="<?php echo e(url('expense/data')); ?>"><i
                                            class="fa fa-circle-o"></i> <?php echo e(trans_choice('general.view',1)); ?> <?php echo e(trans_choice('general.expense',2)); ?>

                                </a></li>
                        <?php endif; ?>
                        <?php if(Sentinel::hasAccess('expenses.create')): ?>
                            <li><a href="<?php echo e(url('expense/create')); ?>"><i
                                            class="fa fa-circle-o"></i> <?php echo e(trans_choice('general.add',2)); ?> <?php echo e(trans_choice('general.expense',1)); ?>

                                </a></li>
                        <?php endif; ?>
                        <?php if(Sentinel::hasAccess('expenses.types.view')): ?>
                            <li><a href="<?php echo e(url('expense/type/data')); ?>"><i
                                            class="fa fa-circle-o"></i> <?php echo e(trans_choice('general.manage',2)); ?> <?php echo e(trans_choice('general.expense',1)); ?> <?php echo e(trans_choice('general.type',2)); ?>

                                </a></li>
                        <?php endif; ?>
                        <?php if(Sentinel::hasAccess('expenses.budget.view')): ?>
                            <li><a href="<?php echo e(url('expense/budget/data')); ?>"><i
                                            class="fa fa-circle-o"></i> <?php echo e(trans_choice('general.manage',2)); ?> <?php echo e(trans_choice('general.budget',1)); ?>

                                </a></li>
                        <?php endif; ?>
                        <?php if(Sentinel::hasAccess('expenses.budget.view')): ?>
                            <li><a href="<?php echo e(url('expense/budget/report')); ?>"><i
                                            class="fa fa-circle-o"></i> <?php echo e(trans_choice('general.budget',1)); ?> <?php echo e(trans_choice('general.report',2)); ?>

                                </a></li>
                        <?php endif; ?>
                    </ul>
                </li>
            <?php endif; ?>
            <?php if(Sentinel::hasAccess('other_income')): ?>
                <li class="treeview <?php if(Request::is('other_income/*')): ?> active <?php endif; ?>">
                    <a href="#">
                        <i class="fa fa-plus"></i> <span><?php echo e(trans_choice('general.other_income',2)); ?></span>
                        <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
                    </a>
                    <ul class="treeview-menu">
                        <?php if(Sentinel::hasAccess('other_income.view')): ?>
                            <li><a href="<?php echo e(url('other_income/data')); ?>"><i
                                            class="fa fa-circle-o"></i> <?php echo e(trans_choice('general.view',2)); ?> <?php echo e(trans_choice('general.other_income',1)); ?>

                                </a></li>
                        <?php endif; ?>
                        <?php if(Sentinel::hasAccess('other_income.create')): ?>
                            <li><a href="<?php echo e(url('other_income/create')); ?>"><i
                                            class="fa fa-circle-o"></i> <?php echo e(trans_choice('general.add',2)); ?> <?php echo e(trans_choice('general.other_income',1)); ?>

                                </a></li>
                        <?php endif; ?>
                        <?php if(Sentinel::hasAccess('other_income.create')): ?>
                            <li><a href="<?php echo e(url('other_income/type/data')); ?>"><i
                                            class="fa fa-circle-o"></i> <?php echo e(trans_choice('general.manage',2)); ?> <?php echo e(trans_choice('general.other_income',1)); ?> <?php echo e(trans_choice('general.type',2)); ?>

                                </a></li>
                        <?php endif; ?>
                    </ul>
                </li>
            <?php endif; ?>
            <?php if(Sentinel::hasAccess('payroll')): ?>
                <li class="treeview <?php if(Request::is('payroll/*')): ?> active <?php endif; ?>">
                    <a href="#">
                        <i class="fa fa-paypal"></i> <span><?php echo e(trans_choice('general.payroll',1)); ?></span>
                        <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
                    </a>
                    <ul class="treeview-menu">
                        <?php if(Sentinel::hasAccess('payroll.view')): ?>
                            <li><a href="<?php echo e(url('payroll/data')); ?>"><i
                                            class="fa fa-circle-o"></i> <?php echo e(trans_choice('general.view',2)); ?> <?php echo e(trans_choice('general.payroll',1)); ?>

                                </a></li>
                        <?php endif; ?>
                        <?php if(Sentinel::hasAccess('payroll.create')): ?>
                            <li><a href="<?php echo e(url('payroll/create')); ?>"><i
                                            class="fa fa-circle-o"></i> <?php echo e(trans_choice('general.add',1)); ?> <?php echo e(trans_choice('general.payroll',1)); ?>

                                </a></li>
                        <?php endif; ?>
                        <?php if(Sentinel::hasAccess('payroll.update')): ?>
                            <li><a href="<?php echo e(url('payroll/template')); ?>"><i
                                            class="fa fa-circle-o"></i> <?php echo e(trans_choice('general.manage',1)); ?> <?php echo e(trans_choice('general.payroll',1)); ?> <?php echo e(trans_choice('general.template',2)); ?>

                                </a></li>
                        <?php endif; ?>
                    </ul>
                </li>
            <?php endif; ?>
            <?php if(Sentinel::hasAccess('custom_fields')): ?>
                <li class="treeview <?php if(Request::is('custom_field/*')): ?> active <?php endif; ?>">
                    <a href="#">
                        <i class="fa fa-list"></i> <span><?php echo e(trans_choice('general.custom_field',2)); ?></span>
                        <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
                    </a>
                    <ul class="treeview-menu">
                        <?php if(Sentinel::hasAccess('custom_fields.view')): ?>
                            <li><a href="<?php echo e(url('custom_field/data')); ?>"><i
                                            class="fa fa-circle-o"></i> <?php echo e(trans_choice('general.view',2)); ?> <?php echo e(trans_choice('general.custom_field',2)); ?>

                                </a></li>
                        <?php endif; ?>
                        <?php if(Sentinel::hasAccess('custom_fields.create')): ?>
                            <li><a href="<?php echo e(url('custom_field/create')); ?>"><i
                                            class="fa fa-circle-o"></i> <?php echo e(trans_choice('general.add',2)); ?> <?php echo e(trans_choice('general.custom_field',1)); ?>

                                </a></li>
                        <?php endif; ?>
                    </ul>
                </li>
            <?php endif; ?>
            <?php if(Sentinel::hasAccess('users')): ?>
                <li class="treeview <?php if(Request::is('user/*')): ?> active <?php endif; ?>">
                    <a href="<?php echo e(url('user/data')); ?>">
                        <i class="fa fa-users"></i> <span><?php echo e(trans_choice('general.user',2)); ?></span>
                        <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
                    </a>
                    <ul class="treeview-menu">
                        <?php if(Sentinel::hasAccess('users.view')): ?>
                            <li><a href="<?php echo e(url('user/data')); ?>">
                                    <i class="fa fa-circle-o"></i>
                                    <span><?php echo e(trans_choice('general.view',2)); ?> <?php echo e(trans_choice('general.user',2)); ?></span>
                                </a></li>
                        <?php endif; ?>
                        <?php if(Sentinel::hasAccess('users.roles.view')): ?>
                            <li><a href="<?php echo e(url('user/role/data')); ?>"><i
                                            class="fa fa-circle-o"></i><?php echo e(trans_choice('general.manage',2)); ?> <?php echo e(trans_choice('general.role',2)); ?>

                                </a></li>
                        <?php endif; ?>
                        <?php if(Sentinel::hasAccess('users.create')): ?>
                            <li><a href="<?php echo e(url('user/create')); ?>"><i
                                            class="fa fa-circle-o"></i><?php echo e(trans_choice('general.add',2)); ?> <?php echo e(trans_choice('general.user',1)); ?>

                                </a></li>
                        <?php endif; ?>
                    </ul>
                </li>
            <?php endif; ?>
            <?php if(Sentinel::hasAccess('audit_trail')): ?>
                <li class="<?php if(Request::is('audit_trail/*')): ?> active <?php endif; ?>">
                    <a href="<?php echo e(url('audit_trail/data')); ?>">
                        <i class="fa fa-area-chart"></i> <span><?php echo e(trans_choice('general.audit_trail',2)); ?></span>
                    </a>
                </li>
            <?php endif; ?>
            <?php if(Sentinel::hasAccess('settings')): ?>
                <li class="treeview <?php if(Request::is('setting/*')): ?> active <?php endif; ?>">
                    <a href="#">
                        <i class="fa fa-cog"></i> <span><?php echo e(trans_choice('general.setting',2)); ?></span>
                        <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
                    </a>
                    <ul class="treeview-menu">
                        <?php if(Sentinel::hasAccess('settings.general.view')): ?>
                            <li><a href="<?php echo e(url('setting/general')); ?>"><i
                                            class="fa fa-circle-o"></i> <?php echo e(trans_choice('general.general',1)); ?>

                                </a></li>
                        <?php endif; ?>
                        <?php if(Sentinel::hasAccess('settings.organisation.view')): ?>
                            <li><a href="<?php echo e(url('setting/organisation')); ?>"><i
                                            class="fa fa-circle-o"></i> <?php echo e(trans_choice('general.organisation',1)); ?>

                                </a></li>
                        <?php endif; ?>
                    </ul>
                </li>
            <?php endif; ?>
        </ul>
    </section>
    <!-- /.sidebar -->
</aside>
