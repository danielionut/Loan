<style>
    table {
        width: 100%;
        border-collapse: collapse;
        font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
        font-size: 10px;
    }

    th, td {
        padding: 10px;
        text-align: left;
        border-bottom: 1px solid #ddd;
    }


    .style-1 {
        color: white;
        padding-left: 10pt;
        font-size: 14pt;
        font-family: "Arial";
        font-weight: bold;
        font-style: normal;
        text-decoration: none;
        text-align: left;
        word-spacing: 0pt;
        letter-spacing: 0pt;
        white-space: pre-wrap;
        background-color: #339933;
    }
    .style-2 {
        color: black;
        padding-right: 1pt;
        font-size: 8pt;
        font-family: "Arial";
        font-weight: bold;
        font-style: normal;
        text-decoration: none;
        text-align: left;
        word-spacing: 0pt;
        letter-spacing: 0pt;
        white-space: pre-wrap;
    }
    .style-3 {
        color: black;
        padding-right: 1pt;
        font-size: 8pt;
        font-family: "Arial Narrow";
        font-weight: normal;
        font-style: normal;
        text-decoration: none;
        text-align: right;
        word-spacing: 0pt;
        letter-spacing: 0pt;
        white-space: pre-wrap;
    }
</style>
<div>

    <table class="table  table-condensed table-hover">
        <tbody>
        <tr style="height: 25pt">
            <td colspan="6" valign="middle"
                class="style-1"> <?php echo e(trans_choice('general.grant',1)); ?>  <?php echo e(trans_choice('general.disbursement',2)); ?></td>
        </tr>
        <tr style="height: 15pt">
            <td valign="middle" class="style-2"><?php echo e(trans_choice('general.from',1)); ?> :</td>
            <td valign="middle" class="style-3"><?php echo e($start_date); ?></td>
            <td colspan="2" valign="middle"
                class="style-4"><?php echo e(trans_choice('general.report',1)); ?> <?php echo e(trans_choice('general.run',1)); ?> <?php echo e(trans_choice('general.date',1)); ?>

                :
            </td>
            <td colspan="2" valign="middle" class="style-5"> <?php echo e(date("Y-m-d H:i:s")); ?></td>
        </tr>
        <tr style="height: 45pt">
            <td valign="middle" class="style-2"><?php echo e(trans_choice('general.to',1)); ?> :</td>
            <td valign="middle" class="style-3"><?php echo e($end_date); ?></td>
            <td colspan="4"></td>
        </tr>
        <tr class="">
            <td><?php echo e(trans_choice('general.id',1)); ?></td>
            <td><?php echo e(trans_choice('general.client',1)); ?></td>
            <td><?php echo e(trans_choice('general.grant',1)); ?> <?php echo e(trans_choice('general.officer',1)); ?> </td>
            <td><?php echo e(trans_choice('general.amount',1)); ?></td>
            <td><?php echo e(trans_choice('general.disbursement',1)); ?> <?php echo e(trans_choice('general.date',1)); ?></td>
            <td><?php echo e(trans_choice('general.channel',1)); ?></td>
        </tr>
        <?php
        $total_amount = 0;
        $decimals = 2;
        ?>
        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php

            $decimals = $key->decimals;

            $amount = $key->amount;
            $total_amount = $total_amount + $amount;

            ?>
            <tr>
                <td><?php echo e($key->id); ?></td>
                <td>

                    <?php if($key->client_type=="client"): ?>
                        <?php if(!empty($key->client)): ?>
                            <?php if($key->client->client_type=="individual"): ?>
                                <?php echo e($key->client->first_name); ?> <?php echo e($key->client->middle_name); ?> <?php echo e($key->client->last_name); ?>

                            <?php endif; ?>
                            <?php if($key->client->client_type=="business"): ?>
                                <?php echo e($key->client->full_name); ?>

                            <?php endif; ?>
                        <?php endif; ?>
                    <?php endif; ?>
                    <?php if($key->client_type=="group"): ?>
                        <?php if(!empty($key->group)): ?>
                            <?php echo e($key->group->name); ?>

                        <?php endif; ?>
                    <?php endif; ?>

                </td>
                <td>
                    <?php if(!empty($key->grant_officer)): ?>
                        <?php echo e($key->grant_officer->first_name); ?>  <?php echo e($key->grant_officer->last_name); ?>

                    <?php endif; ?>
                </td>
                <td><?php echo e(number_format($amount,$decimals)); ?></td>
                <td><?php echo e($key->disbursement_date); ?></td>
                <td>
                    <?php if(!empty($key->payment_detail)): ?>
                        <?php if(!empty($key->payment_detail->type)): ?>
                            <?php echo e($key->payment_detail->type->name); ?>

                        <?php endif; ?>
                    <?php endif; ?>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
        <tfoot>
        <tr>
            <td colspan="3"></td>
            <td><b><?php echo e(number_format($total_amount,$decimals)); ?></b></td>
            <td colspan="2"></td>
        </tr>
        </tfoot>
    </table>
</div>