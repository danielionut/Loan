<?php $__env->startSection('title'); ?>
    <?php echo e(trans_choice('general.add',1)); ?> <?php echo e(trans_choice('general.loan',1)); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="box box-primary">
        <div class="box-header with-border">
            <h3 class="box-title"><?php echo e(trans_choice('general.add',1)); ?> <?php echo e(trans_choice('general.loan',1)); ?></h3>

            <div class="box-tools pull-right">
                <button onclick="window.history.back()" class="btn btn-info btn-sm">
                    <?php echo e(trans_choice('general.cancel',1)); ?>

                </button>
            </div>
        </div>

        <div class="box-body form-horizontal">
            <div class="form-group" id="">
                <label for="type"
                       class="control-label col-md-3"><?php echo e(trans_choice('general.type',1)); ?>

                </label>
                <div class="col-md-5">
                    <select name="type" class="form-control " id="type"
                            required>
                        <option></option>
                        <option value="client"><?php echo e(trans_choice('general.client',1)); ?></option>
                        <option value="group"><?php echo e(trans_choice('general.group',1)); ?></option>
                    </select>
                </div>
            </div>
            <div class="form-group" id="clients_div" style="display: none">
                <label for="client_id"
                       class="control-label col-md-3"><?php echo e(trans_choice('general.client',1)); ?></label>
                <div class="col-md-5">
                    <select name="client_id" class="form-control select2" id="client_id">
                        <option></option>
                        <?php $__currentLoopData = \App\Models\Client::where('status', 'active')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($key->id); ?>">
                                <?php if($key->client_type=="individual"): ?>
                                    <?php echo e($key->first_name); ?> <?php echo e($key->middle_name); ?> <?php echo e($key->last_name); ?>

                                    (<?php echo e($key->account_no); ?>)
                                <?php else: ?>
                                    <?php echo e($key->full_name); ?> (<?php echo e($key->account_no); ?>

                                    )
                                <?php endif; ?>
                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </div>
            <div class="form-group" id="groups_div" style="display: none">
                <label for="group_id"
                       class="control-label col-md-3"><?php echo e(trans_choice('general.group',1)); ?></label>
                <div class="col-md-5">
                    <select name="group_id" class="form-control select2" id="group_id">
                        <option></option>
                        <?php $__currentLoopData = \App\Models\Group::where('status', 'active')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($key->id); ?>">
                                <?php echo e($key->name); ?>(<?php echo e($key->account_no); ?> )
                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </div>
            <div class="form-group" id="">
                <label for="loan_product_id"
                       class="control-label col-md-3"><?php echo e(trans_choice('general.product',1)); ?></label>
                <div class="col-md-5">
                    <select name="loan_product_id" class="form-control select2" id="loan_product_id">
                        <option></option>
                        <?php $__currentLoopData = \App\Models\LoanProduct::get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($key->id); ?>">
                                <?php echo e($key->name); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </div>
            <div class="form-group">
                <label for=""
                       class="control-label col-md-3"></label>
                <div class="col-md-5">
                    <button type="submit" class="btn btn-primary" id="next"><?php echo e(trans_choice('general.next',1)); ?></button>
                </div>
            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('footer-scripts'); ?>
    <script>
        $('#type').change(function (e) {
            if ($("#type").val() == "client") {
                $("#clients_div").show();
                $("#groups_div").hide();
            }
            if ($("#type").val() == "group") {
                $("#clients_div").hide();
                $("#groups_div").show();
            }
        });
        $("#next").click(function (e) {
            var type = $("#type").val();
            var group_id = $("#group_id").val();
            var client_id = $("#client_id").val();
            var loan_product_id = $("#loan_product_id").val();
            if (type == "") {
                alert("Please select type");
            } else {
                if (type == "client" && client_id != "" && loan_product_id != "") {
                    document.location = "<?php echo e(url('loan/create_client_loan/')); ?>/" + client_id + "/" + loan_product_id;
                } else if (type == "group" && group_id != "" && loan_product_id != "") {
                    document.location = "<?php echo e(url('loan/create_group_loan/')); ?>/" + group_id + "/" + loan_product_id;
                } else {
                    alert("Select client or Product");
                }
            }

        })
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>