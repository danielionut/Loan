<?php $__env->startSection('title'); ?><?php echo e(trans_choice('general.grant',1)); ?> <?php echo e(trans_choice('general.report',2)); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="box box-primary">
        <div class="box-header with-border">
            <h3 class="box-title"> <?php echo e(trans_choice('general.grant',1)); ?> <?php echo e(trans_choice('general.report',2)); ?></h3>

            <div class="box-tools pull-right">

            </div>
        </div>
        <div class="box-body">
            <table id="" class="table table-striped table-hover">
                <thead>
                <tr>
                    <th><?php echo e(trans_choice('general.name',1)); ?></th>
                    <th><?php echo e(trans_choice('general.description',1)); ?></th>
                    <th><?php echo e(trans_choice('general.action',1)); ?></th>
                </tr>
                </thead>
                <tbody>

                <tr>
                    <td>
                        <a href="<?php echo e(url('report/grant_report/disbursement_report')); ?>"><?php echo e(trans_choice('general.disbursement',2)); ?> <?php echo e(trans_choice('general.report',1)); ?></a>
                    </td>
                    <td>
                        <?php echo e(trans_choice('general.grant_disbursement_report_description',1)); ?>

                    </td>
                    <td><a href="<?php echo e(url('report/grant_report/disbursement_report')); ?>"><i class="icon-search4"></i> </a>
                    </td>
                </tr>


                </tbody>
            </table>
        </div>
        <!-- /.box-body -->
    </div>
    <!-- /.box -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('footer-scripts'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>